#include <stdbool.h>
#include <stddef.h>

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_core.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_busy.h"

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

extern struct deferable_manager deferal_busy_manager;


#define os_enter_critical_section() kernel_core.dsr_busy = true;
/*
 *	Leave Critical Exception Section Re-Enabling both Global Interrupts and Exceptions if
 *	when previously entering they where both enabled
 */

#define os_leave_critical()  kernel_core.dsr_busy = false;

#define os_leave_critical_section()  critical_section_exit(); kernel_core.dsr_busy = false;


void internal_add_execution_list(struct deferred_service_routine * dsr_packet);

/*
 *	internal_allocate_packet, allocates a dsr's to the Invoking Call
 */
struct deferred_service_routine * internal_allocate_packet(void);
struct deferred_service_routine * internal_allocate_packet(void){

	volatile struct deferred_service_routine * packet;

	os_enter_critical_section();
	packet = deferral_service__controller.free_ptr;

	if( deferral_service__controller.nr_free == 1){
		deferral_service__controller.nr_free = 0;           // Unmark Priority Map
	}
	else
	{
		deferral_service__controller.nr_free--;

		deferral_service__controller.free_ptr = (struct deferred_service_routine *)packet->next_packet;

		packet->previous_packet->next_packet = packet->next_packet;
		packet->next_packet->previous_packet = packet->previous_packet;
	} os_leave_critical();

	return((struct deferred_service_routine *)packet);
}


/*
 *	internal_return_dsr_packet, returns a completed dsr to the Double Link List Resource
 */
void internal_return_dsr_packet(struct deferred_service_routine * packet);
void internal_return_dsr_packet(struct deferred_service_routine * packet){

	os_enter_critical_section();
	if( deferral_service__controller.nr_free == 0){
		deferral_service__controller.free_ptr	= packet;
		packet->next_packet						= packet;
		packet->previous_packet					= packet;
		deferral_service__controller.nr_free	= 1;
	}
	else{
		deferral_service__controller.nr_free++;
		packet->next_packet = deferral_service__controller.free_ptr;
		packet->previous_packet = deferral_service__controller.free_ptr->previous_packet;
		deferral_service__controller.free_ptr->previous_packet->next_packet = packet;
		deferral_service__controller.free_ptr->previous_packet = packet;
	} os_leave_critical_section();
}





void critical_section_exit(void){

	/*
	 * handle any deferal's that where waiting on a deferall to process or access
	 * to the deferal system
	 */

	struct identifier * id = deferal_busy_manager.start;

	for(int i = 0; i < deferal_busy_manager.nr; i++){

		if(id->status == true){

			id->status = false;

			/* Defer dsr until we have finished processing Interrupts and Exceptions */
			struct deferred_service_routine * dsr_packet = internal_allocate_packet();

			dsr_packet->handler		= id->handler;
			dsr_packet->arguments	= id->argument;

			internal_add_execution_list(dsr_packet);
		}
		id = id->next;
	}
}

/*
 *	api_invoke_dsr is called by the Interrupt to pass Operating System calls to made from within
 *	Interrupts
 */
void api_invoke(struct identifier * id, int argument){

	if(kernel_core.dsr_busy == false){

		/* Defer dsr until we have finished processing Interrupts and Exceptions */
		struct deferred_service_routine * dsr_packet = internal_allocate_packet();

		dsr_packet->handler		= id->handler;
		dsr_packet->arguments	= argument;

		internal_add_execution_list(dsr_packet);
	}
	else{

		// Defer the Deferral
		id->argument = argument;
		id->status = true;
	}
}



/*
 *	internal_add_execution_list, adds a dsr to a Double Link List containing all the dsr's
 *	to be Executes by the Operating System
 */
void internal_add_execution_list(struct deferred_service_routine * dsr_packet){

	// Add dsr to the list requiring execution
	os_enter_critical_section();

	if( deferral_service__controller.nr_active == 0){
		deferral_service__controller.start_ptr	= dsr_packet;
		dsr_packet->next_packet					= dsr_packet;
		dsr_packet->previous_packet				= dsr_packet;
		deferral_service__controller.nr_active	= 1;
	}
	else{
		deferral_service__controller.nr_active++;

		dsr_packet->next_packet = deferral_service__controller.start_ptr;
		dsr_packet->previous_packet = deferral_service__controller.start_ptr->previous_packet;

		deferral_service__controller.start_ptr->previous_packet->next_packet = dsr_packet;
		deferral_service__controller.start_ptr->previous_packet = dsr_packet;
	} os_leave_critical();
}

/*
 *	Execute Link service Routine
 */
static void remote_call_link_service_routine(void * execute, int arguments){

	/* Local Function Call, i.e. Re-entrance */  void ( * dsr_handler )(int);

	// Link service Routine Call
	core_executing_task->dsr_active = true;

	// Validate The dsr to be Executed
	if(execute != NULL){ dsr_handler = execute; dsr_handler(arguments);
	}

	// Clear Link Serivce Routine Flag
	core_executing_task->dsr_active = false;
}

/*
 *	internal_remove_execution_list, removes the Link service Routine from the Double Link List
 */
void internal_remove_execution_list(struct deferred_service_routine * packet);
void internal_remove_execution_list(struct deferred_service_routine * packet){

	os_enter_critical_section();
	if( deferral_service__controller.nr_active == 1){
		deferral_service__controller.nr_active = 0;
	}
	else
	{
		deferral_service__controller.nr_active--;
		deferral_service__controller.start_ptr = (struct deferred_service_routine *)packet->next_packet;

		packet->previous_packet->next_packet = packet->next_packet;
		packet->next_packet->previous_packet = packet->previous_packet;
	} os_leave_critical_section();
}



#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"
/*
 *	api_configure_dsr_controller, adds Empty dsr's to the Controller
 */
unsigned char api_configure_dsr_controller(int nr_system_packets){

	os_enter_critical_section();

	struct deferred_service_routine * packet;

	for(int i = 0; i < nr_system_packets; i++){

		packet = malloc(sizeof(struct deferred_service_routine));
		internal_return_dsr_packet(packet);
	} os_leave_critical_section();
	return (true);
}



void internal_execute_dsr_within_services(void){

	volatile struct deferred_service_routine * packet;

	while(deferral_service__controller.nr_active != 0){

		// Get first API call to Execute
		packet = deferral_service__controller.start_ptr;

		// Remove dsr from the system
		internal_remove_execution_list((struct deferred_service_routine *)packet);

		// Call Application api_programmer Interface
		remote_call_link_service_routine(packet->handler, packet->arguments);

		// Return dsr Packet to free List
		internal_return_dsr_packet((struct deferred_service_routine *)packet);
	}
}
