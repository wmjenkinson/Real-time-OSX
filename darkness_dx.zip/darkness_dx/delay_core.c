#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"

	#include "trace.h"
	#include "serial/console.h"

void internal_remove_delay(struct task_ctrl_obj * tcb);

/*
 *	internal_setup_realtime_clock, Loads the OperatingSystem Tick with the next delay due to occur therefore
 *	avoiding having to execute the delay system api_program every tick
 */
void internal_setup_realtime_clock(void);
void internal_setup_realtime_clock(void){

	api_system_gateway();

	// Stop Delay Processing on the Tick Interrupt
	delay_queue.target = 0;
	int accumalated_ticks = delay_queue.delay_accumulator; delay_queue.delay_accumulator = 0;

	// initialize Delay target
	int target = 0, updated_priority = 63;

	// retrieve number of delayed tasks
	int nr_delayed = delay_queue.nr_tcb;

	if((nr_delayed == 0) && (core_executing_task != delay_manager)){

		if(delay_manager->task_status != DORMANT){
			internal_kernel_remove_task(delay_manager);
		}
		return;
	}

	// get first delayed task
	struct task_ctrl_obj * tcb = delay_queue.tcb_next_exe;



	// decrement the current running from all the delayed tasks
	for(int i = 0; i < nr_delayed; i++){

		if((tcb->delay_counter - accumalated_ticks) <= 0)
			tcb->delay_counter = 0;

		else
			tcb->delay_counter -= accumalated_ticks;

		tcb = tcb->delay_next;
	}



	for(int i = 0; i < nr_delayed; i++){

		// initialize the first target
		if(i == 0){

			updated_priority = tcb->delta_priority;
			target = tcb->delay_counter;
		}

		else if(tcb->delay_counter == target){

			if(updated_priority > tcb->delta_priority){

				// Set Delay Manager Priority to that of the target Task up Next to Execute on the Delay Manager
				updated_priority = tcb->delta_priority;
			}
		}

		// set target to the lowest Timeout
		else if(tcb->delay_counter < target){

			// Set Delay Manager Priority to that of the target Task up Next to Execute on the Delay Manager
			updated_priority = tcb->delta_priority;
			target = tcb->delay_counter;
		}

		// Traverse the Delayed Lists
		tcb = tcb->delay_next;
	}



	// if delay manager is ready to executing or executing then update tasks priority
	if(delay_manager->task_status != DORMANT){

		internal_kernel_remove_task(delay_manager);
		delay_manager->delta_priority = updated_priority; internal_kernel_insert_task(delay_manager);
	}

	else if((target == 0) && (delay_manager->task_status == DORMANT) && (delay_queue.nr_tcb != 0)){

		delay_manager->delta_priority = updated_priority;
		internal_kernel_insert_task(delay_manager);
	}

	// configure new delay settings
	delay_manager->delta_priority = updated_priority;
	delay_queue.target = target;
}




/*
 *	internal_delay_manager, Is a Operating System api_program that Processes Delays on the System, It only
 *	Executes when a Delay is due to Process and not every time the Kernel Heart Beat/Tick occurs
 */
void internal_delay_manager(void);
void internal_delay_manager(void){



	int nr_delayed, delayCompute;

	struct task_ctrl_obj * tcb;
	struct task_ctrl_obj * next_tcb;

	do{

		nr_delayed = delay_queue.nr_tcb;
		//delay_queue.delay_monitor = 0;					// Delays added while delay manager is running

		tcb = delay_queue.tcb_next_exe;

		while(nr_delayed--){//} + delay_queue.delay_monitor) != 0){		// Travel Delay Queue

			// Scope Interest!!!
			{
				api_system_gateway();
				next_tcb = (struct task_ctrl_obj *)tcb->delay_next;


				delayCompute = tcb->delay_counter - delay_queue.delay_accumulator;

				if(delayCompute <= 0){							// If task control object delay counter equals Zero then prepare task

					switch (tcb->task_status){
/*
						case BUFFER_WAITING:
							internal_buffer_remove_task((struct ipc_buffer_object *)tcb->resource_waiting, (struct task_ctrl_obj *)tcb);
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;

						case SEMAPHORE_WAITING:
							internal_semaphore_remove_task((struct ipc_semaphore_object *)tcb->resource_waiting, (struct task_ctrl_obj *)tcb);
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;

						case FUTEX_WAITING:
							internal_futex_remove_task((struct ipc_futex_object *)tcb->resource_waiting, (struct task_ctrl_obj *)tcb);
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;

						case MAILBOX_WAITING:
							internal_mailbox_remove_task((struct ipc_mailbox_object *)tcb->resource_waiting, (struct task_ctrl_obj *)tcb);
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;

						case WAITING_ON_EVENT:
							internal_remove_node((struct ipc_event_object *)tcb->resource_waiting, tcb->node_object);
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;

						case MUTEX_WAITING:
							//remove_and_recalibrate_mutex_priorities((struct task_ctrl_obj *)tcb);
						break;

						case PIPE_WAITING:
							internal_pipe_remove_task((struct ipc_pipe_object *)tcb->resource_waiting, (struct task_ctrl_obj *)tcb);
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;
*/
						case DELAYED:
							internal_remove_delay((struct task_ctrl_obj *)tcb);
						break;

						default:
						break;
					}

					internal_kernel_insert_task((struct task_ctrl_obj *)tcb);	// Insert task control object back onto the kernel
					tcb->internal_ctrl = TIMEOUT;								// specify that the task is returning having timed out
				}
				tcb = next_tcb;													// move to next task control block object
			}
		}

		// Kernel Critical Section
		core_executing_task->application_mode = true;

		internal_kernel_remove_task(delay_manager);
		internal_setup_realtime_clock();

		internal_executive_dispatcher();

		// Reset status to Normal Execution Mode
		core_executing_task->application_mode = false;

	} while (true);
}


/* Insert Task unot the Delay Queue, this structure is a Double Linked List	*/
unsigned char api_delay_task(struct task_ctrl_obj * tcb, int delay);
unsigned char api_delay_task(struct task_ctrl_obj * tcb, int delay){

	api_system_gateway();

	delay_queue.delay_monitor++;

	tcb->internal_ctrl = acknowledge;
	tcb->delay_counter = delay + delay_queue.delay_accumulator;

	unsigned char task_status = tcb->task_status;


	// Add to Double Link List Containing the Information of Each Task Delayed
	{
		if(delay_queue.nr_tcb == 0){
			delay_queue.tcb_next_exe	= tcb;
			tcb->delay_next				= tcb;
			tcb->delay_prev				= tcb;
			delay_queue.nr_tcb = 1;
		}
	else{
		delay_queue.nr_tcb++;
		tcb->delay_next = (struct task_ctrl_obj *)delay_queue.tcb_next_exe;
		tcb->delay_prev = delay_queue.tcb_next_exe->delay_prev;
		delay_queue.tcb_next_exe->delay_prev->delay_next = tcb;
		delay_queue.tcb_next_exe->delay_prev = tcb;
		}
	}


	// Process next Delay Due to be Proessed
	internal_setup_realtime_clock();

	// If Call not from a Resource Request then Task Status Equals DELAYED
	if (task_status == EXECUTING){

		// Task can be Processed Here, Simply Delay Task
		internal_kernel_remove_task(tcb);
		tcb->task_status = DELAYED;

		internal_executive_dispatcher();

		if(tcb->internal_ctrl == TIMEOUT){
			tcb->internal_ctrl = acknowledge; return(TIMEOUT);
		}
	}

	// If Call not from a Resource Request then Task Status Equals DELAYED
	else if (task_status == READY){

		// Task can be Processed Here, Simply Delay Task
		internal_kernel_remove_task(tcb);
		tcb->task_status = DELAYED;

		return SUCCESSFUL;
	}
	return SUCCESSFUL;
}


// Remove Task from Double Link List
void internal_remove_delay(struct task_ctrl_obj * tcb){

	api_system_gateway();

	tcb->delay_counter = 0;

	if(core_executing_task != delay_manager)
		delay_queue.delay_monitor--;

	// Remove the delayed task from the Delay Managers internal queuing interface
	{
		if(delay_queue.nr_tcb == 1){
			delay_queue.nr_tcb = 0;
		}
		else
		{
			delay_queue.nr_tcb--;
			if(delay_queue.tcb_next_exe == tcb){
				delay_queue.tcb_next_exe = (struct task_ctrl_obj *)tcb->delay_next;
			}
			tcb->delay_prev->delay_next  = tcb->delay_next;
			tcb->delay_next->delay_prev  = tcb->delay_prev;
		}

		if(tcb->task_status == DELAYED){
			tcb->task_status = DORMANT;
		}
	}
}
