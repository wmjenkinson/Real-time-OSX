/*
 * name_space.h
 *
 *  Created on: 24 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_NAME_SPACE_H_
#define DARKNESS_DX_NAME_SPACE_H_



struct name{

	int nr;
	struct task_id * first;
	};


struct task_id{

	char name [20];
	struct task_ctrl_obj * id;

	struct task_id * next;
	struct task_id * prev;
	};



extern void add_system_name(struct task_id * );
extern void remove_system_name(struct task_id * );

extern struct task_ctrl_obj * get_task_id(char const *);
extern char * get_task_name(struct task_ctrl_obj * );

extern struct task_id * get_log_file(struct task_ctrl_obj * );




#endif /* DARKNESS_DX_NAME_SPACE_H_ */
