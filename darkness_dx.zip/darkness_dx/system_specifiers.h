/*
 * system_specifiers.h
 *
 *  Created on: 21 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_SYSTEM_SPECIFIERS_H_
#define DARKNESS_DX_SYSTEM_SPECIFIERS_H_

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_core.h"

struct task_ctrl_obj	* delay_manager,
			  	  	  	* timer_manager,
						* ideal_task,
						* OSTCBHighRdy;


struct task_ctrl_obj * core_executing_task;	// Current Task Executing, as the Value is updated in Interrupt service Routines

volatile struct delay_structure delay_queue;
volatile struct core_structure kernel_core;

volatile struct segmented_interrupt_mode deferral_service__controller;

#endif /* DARKNESS_DX_SYSTEM_SPECIFIERS_H_ */
