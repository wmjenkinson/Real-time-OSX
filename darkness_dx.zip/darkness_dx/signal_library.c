#include "stddef.h"


#include "\atmel-software-package-master\examples\getting_started\darkness_dx\/structs.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\/micro_kernel_core.h"

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\signal_library.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

// Signal Manager service
void internal_signal_server(struct task_ctrl_obj * localTCB){

	api_system_gateway();

	struct task_ctrl_obj   * tcb;
	struct signal_pending  * signal_service;
	struct signal_ctrl_obj * handler_service;

	void (* handler)(void);

	unsigned short int signal;

	tcb = (struct task_ctrl_obj *)localTCB;


	// begin looping to access signals sent
	for(unsigned short int j = 0;j < tcb->signals->nr_signal_received;j++){

		// Get first Signal sent.  If none then the loop will fail
		signal_service = (struct signal_pending *)tcb->signals->start;

		// Obtain Signal Command
		signal = signal_service->signal_cmd;

		// Begin looping through registered signals looking for a match
		for(unsigned short int k = 0;k < tcb->signal_management->nr_signal_registered;k++){

			// Get first handler registered
			handler_service = (struct signal_ctrl_obj *)tcb->signal_management->start;

			// If match detected then call registered signal
			if(signal == handler_service->signal_nr){

				// Call Handler
				handler = handler_service->__handler;
				handler();
			}
			// Move to next registered signal
			tcb->signal_management->start = tcb->signal_management->start->next;
		}
		tcb->signals->start = tcb->signals->start->next_signal;
	}
	// Acknowledge all signals as being processed
	internal_acknowledge_signals(localTCB);
}

/* This function registered signals to the pass task Ctrl block */
unsigned char api_register_signal(void * handler, unsigned char signal_nr){ api_system_gateway();

	struct task_ctrl_obj   * tcb;
	struct ipc_signal_obj  * queue;
	struct signal_ctrl_obj * signal__;

	// Obtain task ctrl block ID of executng task to register signals to
	tcb   = (struct task_ctrl_obj *)core_executing_task;
	// Obtain pointer to queue to register signal handlers onto
	queue =  (struct ipc_signal_obj *)tcb->signal_management;

	// Allocate memory to signal
	signal__ = malloc(sizeof(struct signal_ctrl_obj));
	if(signal__ == NULL){
		//print_dbg("Error Allocating Memory for a Signal\n\r");
		return(FAILURE);
	}

	// Generate data to be used for the signal
	signal__->__handler = handler;
	signal__->signal_nr = signal_nr;

	// place on double link queue
	if( queue->nr_signal_registered == 0){
		queue->start		= signal__;
		signal__->next		= signal__;
		signal__->prev		= signal__;
		queue->nr_signal_registered	= 1;
	}
	else{
		queue->nr_signal_registered++;
		signal__->next = (struct signal_ctrl_obj *)queue->start;
		signal__->prev = queue->start->prev;
		queue->start->prev->next = signal__;
		queue->start->prev = signal__;
	}
	return(SUCCESSFUL);
}

/* Function to unregister a signal from the calling function */
unsigned char internal_unregister_signal(void * handler, unsigned char signal_nr);
unsigned char internal_unregister_signal(void * handler, unsigned char signal_nr){ api_system_gateway();

	// Obtain task ctrl block ID
	struct task_ctrl_obj  * tcb = (struct task_ctrl_obj *)core_executing_task;
	struct ipc_signal_obj * queue = (struct ipc_signal_obj *)tcb->signal_management;

	struct signal_ctrl_obj * signal__;

	// Obtain signal on the double link list, searching linary
	signal__ = (struct signal_ctrl_obj *)queue->start;
	while(!((signal__->__handler == handler)&&(signal__->signal_nr == signal_nr))){
		signal__ = (struct signal_ctrl_obj *)signal__->next;
	}

	// Remove registered signal from the double link list
	if( queue->nr_signal_registered == 1){
		queue->nr_signal_registered = 0;
	}
	else{
		queue->nr_signal_registered--;
		if(queue->start == signal__)
		queue->start = signal__->next;
		signal__->prev->next = signal__->next;
		signal__->next->prev = signal__->prev;
	}
	free(signal__);

	return(SUCCESSFUL);
}
/* Send signal enqueues a signal to the target task ctrl block signal queueing system */
unsigned char api_send_signal(struct task_ctrl_obj * tcb, unsigned char signal){ api_system_gateway();


	struct ipc_signal_sent * queue = (struct ipc_signal_sent *)tcb->signals;

	// check that the signal has been registered to the target task ctrl block
	// return error to calling task if signal has not been registered
	if(internal_check_registery(tcb, signal) == FAILURE){
		return(ERROR);
	}

	struct signal_pending * signal_comms = internal_allocate_signal();
	if(signal_comms == NULL){
		//print_dbg("Error Allocating Memory for a Sent Signal\n\r");
		return(FAILURE);
	}

	// enqueue signal unto target signal management queue
	signal_comms->signal_cmd = signal;

	if( queue->nr_signal_received == 0){
		queue->start				= signal_comms;
		queue->start->next_signal	= signal_comms;
		queue->start->prev_signal	= signal_comms;
		queue->nr_signal_received	= 1;
	}
	else{
		queue->nr_signal_received++;
		signal_comms->next_signal = (struct signal_pending *)queue->start;
		signal_comms->prev_signal = queue->start->prev_signal;
		queue->start->prev_signal->next_signal = signal_comms;
		queue->start->prev_signal = signal_comms;
	}
	return(SUCCESSFUL);
}

/* check that signal has been registered to the target task ctrl block */
unsigned char internal_check_registery(struct task_ctrl_obj * tcb, unsigned char signal){ api_system_gateway();

	struct signal_ctrl_obj * handler;
	handler = (struct signal_ctrl_obj *)tcb->signal_management->start;

	for(unsigned short int i = 0;i != tcb->signal_management->nr_signal_registered;i++){
		if(handler->signal_nr == signal){
			return(SUCCESSFUL);
		}
		handler = (struct signal_ctrl_obj *)handler->next;
	}
	return(FAILURE);
}

// acknowledge all signals enqueued on target task ctrl block and delete them
void internal_acknowledge_signals(struct task_ctrl_obj * localTCB){ api_system_gateway();

	struct task_ctrl_obj * tcb = localTCB;

	struct ipc_signal_sent * queue = (struct ipc_signal_sent *)tcb->signals;

	struct signal_pending  * del_signal,
	* signal_pending;

	signal_pending = (struct signal_pending *)queue->start;

	while(queue->nr_signal_received != clear){

		del_signal = signal_pending;
		signal_pending = (struct signal_pending *)signal_pending->next_signal;

		if( queue->nr_signal_received == 1){
			queue->nr_signal_received = 0;
		}
		else
		{
			queue->nr_signal_received--;
			if(queue->start == del_signal){
				queue->start = del_signal->next_signal;
			}

			del_signal->prev_signal->next_signal = del_signal->next_signal;
			del_signal->next_signal->prev_signal = del_signal->prev_signal;
		}
		internal_return_signal(del_signal);
	}
}

unsigned char internal_configure_signals(int nr_system_packets){ api_system_gateway();

	struct signal_pending * signal;

	for(int i = 0; i < nr_system_packets; i++){

		signal = malloc(sizeof(struct signal_pending));
		internal_return_signal(signal);
	}
	return (1);
}


void internal_return_signal(struct signal_pending * signal){ api_system_gateway();


	if( Darkness_Signals.nr_signals == 0){
		Darkness_Signals.free_ptr				= signal;
		signal->next_signal						= signal;
		signal->prev_signal						= signal;
		Darkness_Signals.nr_signals			= 1;
	}
	else{
		Darkness_Signals.nr_signals++;
		signal->next_signal = Darkness_Signals.free_ptr;
		signal->prev_signal = Darkness_Signals.free_ptr->prev_signal;
		Darkness_Signals.free_ptr->prev_signal->next_signal = signal;
		Darkness_Signals.free_ptr->prev_signal = signal;

	}
}



struct signal_pending * internal_allocate_signal(void){ api_system_gateway();

	struct signal_pending * signal;



	signal = Darkness_Signals.free_ptr;

	if( Darkness_Signals.nr_signals == 1){
		Darkness_Signals.nr_signals = 0;           // Unmark Priority Map
	}
	else
	{
		Darkness_Signals.nr_signals--;

		Darkness_Signals.free_ptr = signal->next_signal;

		signal->prev_signal->next_signal = signal->next_signal;
		signal->next_signal->prev_signal = signal->prev_signal;
	}
	return(signal);
}

