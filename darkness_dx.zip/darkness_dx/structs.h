/*
 * structs.h
 *
 *  Created on: 21 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_STRUCTS_H_
#define DARKNESS_DX_STRUCTS_H_


#define kernel_tick 1000
#define TaskGranularity 10

#include <stdbool.h>


/*
**********************************************************************************************************
*                                           DATA TYPES
**********************************************************************************************************
*/
typedef unsigned long long system_events;

		// Kernel UnMap Table is Used to return the Highest Task READY to Run
		static unsigned char const KernelUnMapTbl[] = {
			8, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x00 to 0x0F     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x10 to 0x1F     */
			5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x20 to 0x2F     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x30 to 0x3F     */
			6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x40 to 0x4F     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x50 to 0x5F     */
			5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x60 to 0x6F     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x70 to 0x7F     */
			7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x80 to 0x8F     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0x90 to 0x9F     */
			5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xA0 to 0xAF     */
		 	4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xB0 to 0xBF     */
			6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xC0 to 0xCF     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xD0 to 0xDF     */
			5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,       /* 0xE0 to 0xEF     */
			4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0        /* 0xF0 to 0xFF     */
		};

// Task Ctrl Block, Stores the Status and Task Properties
struct task_ctrl_obj {
	unsigned char * stack_ptr;				// Task Stack Pointer saved by the contest switch
	unsigned char * stack_allocation;		// Pointer for De-allocation of Stack

	int  delay_counter;						// Task delay counter if zero then task is not waiting otherwise
											// we can assume that the task is waiting on a delay request

	unsigned char * mpu_base_mem_addr;
	unsigned char ergonRegion;
	bool mpu_protection;

	char name[20];

	unsigned char	default_priority;		// Default Task Priority	0 - 63
	unsigned char	delta_priority;			// Task Run-time Priority	0 - 63

	unsigned char   total_futexs_held;		// Used to manage the priority inheritance
	unsigned char	ceiling_priority;		// Futex Ceiling priority
	bool			sem_rw_type;

	unsigned char	task_status;			// Task Status, i.e., READY, WAITING, DORMANT, DELAYED
	unsigned char	internal_ctrl;			// Ctrl Status, i.e. TIMEOUT, SEMACK, etc

	void * datum_return;							// Generic datum return used to return such things as mail
	char					datum_return_1bit;		// Token Return to Task after PENDING
	unsigned char 			datum_return_8bit;		// Token Return to Task after PENDING
	unsigned short int		datum_return_16bit;		// Token Return to Task after PENDING
	unsigned int			datum_return_32bit;		// Token Return to Task after PENDING
	unsigned long long int	datum_return_64bit;		// Token Return to Task after PENDING

	int	tcb_flags;									// system_events Return after Pending on Event

	struct task_ctrl_obj * ReadiedTask;

	volatile int  interrupt_mode;
	volatile bool dsr_active;
	volatile bool application_mode;


	unsigned int tcb_gm_flag_;

	void * resource_waiting;
	char signal_recursion_marker;					// Signal Management structures - we must prevent recursive
													// calls being made when a perfect relationship occurs and the
													// Darkness Kernel tries to perform a recursive call which must
													// be prevented
	struct ipc_signal_obj  *  signal_management;	// Pointers to signals registered with by the task
	struct ipc_signal_sent *  signals;				// Signals pending on the task

	struct event_node * node_object;			// Pointer to the Event that has been packaged as a node
	struct task_ctrl_obj * from;				// used by the mailbox to dictate who we are waiting on mail from
												// when the tcb is waiting on a mailbox

	struct task_ctrl_obj * tcb_next;			// Points to Next Task Ctrl Block on Kernel Scheduler/Resource
	struct task_ctrl_obj * tcb_prev;			// Points to Prev Task Ctrl Block on Kernel Scheduler/Resource
	struct task_ctrl_obj * delay_next;			// Points to Next Task Ctrl Block on Delay Queue
	struct task_ctrl_obj * delay_prev;			// Points to Prev Task Ctrl Block on Delay Queue
};

struct queue_ctrl_object {					// Queue Ctrl Block Manages Double Link Chains of Task Ctrl Blocks
	struct task_ctrl_obj * tcb_next_exe;	// Points to First Task Ctrl Block on the List
	unsigned short int  nr_tcb;				// Number of Task Ctrl Block on List
};






struct delay_structure{									// Queue Ctrl Block Manages Double Link Chains of Task Ctrl Blocks

	struct task_ctrl_obj * tcb_next_exe;	// Points to First Task Ctrl Block on the List
	unsigned int nr_tcb;				// missing one datum. Number of Task Ctrl Block on List

	int task_accumulator;
	int delay_accumulator;

	unsigned int target;

	volatile int delay_monitor;

};


struct core_structure{
	struct queue_ctrl_object priority_levels[64];	//  Server Structure, READY task wait on this structure

	unsigned char priority_map[9];					// Priority Map, Used to Find the Highest Priority Task READY to Run

	unsigned char system_boot;
	volatile bool dsr_busy;

	bool round_robin_trigger;
	unsigned long kernel_stamp;

	unsigned int task_round_robin;
	char system_runtime[13];

};


extern struct task_ctrl_obj	* delay_manager,
			  	  	  		* timer_manager,
							* ideal_task,
							* OSTCBHighRdy;


extern struct task_ctrl_obj * core_executing_task;	// Current Task Executing, as the Value is updated in Interrupt service Routines

extern volatile struct delay_structure delay_queue;

extern volatile struct core_structure kernel_core;

#define Zero			0
#define clear			0
#define FAILURE			0
#define EMPTY			0
#define ERROR			0
#define SUCCESSFUL		1
#define OKAY			1
#define UNSUCCESSFUL    0
#define SEMAPHORE		2
#define TIMEOUT			3
#define SEM_ACK			4
#define RES_WAIT		5
#define DELAYED			6
#define MAILBOX			7
#define service			8
#define OCCUPIED		9
#define OVERWRITE		10
#define STANDARD		11
#define EXCEPTION		13
#define MUTEX			14
#define MUTEX_ACK		15
#define MUTEX_WAIT		16
#define READY			18
#define WAITING			19
#define DORMANT			20
#define EXECUTING		21
#define NODE			22
#define FUTEX			23
#define FUTEX_ACK		24
#define FUTEX_WAIT		25
#define MUTEX_CORE_EN	26
#define acknowledge     27
#define available		28
#define unavailable     29
#define EVENT			30
#define WAITING_ON_EVENT 31
#define HOLDING			32
#define NO_MAIL			33
#define WAITING_ON_MAIL 34

#define to_anyone		(struct task_ctrl_obj *) 35
#define from_anyone     (struct task_ctrl_obj *) 36
#define from_IRQ		(struct task_ctrl_obj *) 36


#define DYN_MEM			37
#define DYN_MEM_ACK		38

#define BYTE            37
#define WORD			38
#define DWORD           39

#define never			0
#define idle			72
#define _group			8
#define Base8			8

#define OVERFLOW_SEM	40
#define TASK			41
#define PERIODIC		42

#define User_Mode					0
#define Supervisor_Mode				1
#define Interrupt_Mode				2
#define Interrupt_0_Mode			2
#define Interrupt_1_Mode			3
#define Interrupt_2_Mode			4
#define Interrupt_3_Mode			5
#define Exception_Mode				6
#define Non_Maskable_Interrupt_Mode 7

#define unified_task struct task_ctrl_obj *

#define SAVED			43
#define SEMAPHORE_WAITING 44
#define FUTEX_WAITING	45
#define MAILBOX_WAITING	46
#define PIPE_WAITING	47
#define MUTEX_WAITING	48
#define BUFFER_WAITING	49
#define ACCESS_DENIED	50

#define NMI 0

#endif /* DARKNESS_DX_STRUCTS_H_ */
