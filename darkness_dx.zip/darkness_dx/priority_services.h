/*
 * priority_services.h
 *
 *  Created on: 22 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_PRIORITY_SERVICES_H_
#define DARKNESS_DX_PRIORITY_SERVICES_H_

/*
 *	Obtain Highest on the Operating System Priority Cube
 */
extern unsigned char internal_resource_retrieve_priority(unsigned char * );

/*
 *	Add Priority Level Active to the Operating System Priority Cube
 */
extern void internal_resource_configure_priority(unsigned char *, unsigned char);

/*
 *	Remove Priority Level Active to the Operating System Priority Cube
 */
extern void internal_resource_unconfigure_priority(unsigned char *, unsigned char);




#endif /* DARKNESS_DX_PRIORITY_SERVICES_H_ */
