/*
 * timers.h
 *
 *  Created on: 3 Sep 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_TIMERS_H_
#define DARKNESS_DX_TIMERS_H_

#include "stdbool.h"


#define ONE_SHOT 1

extern void create_timer(void *, unsigned int, bool, int);
extern void confirgure_timers(void);
extern void timer_manager_exe(void);

struct timer_function{

	struct timer_function * next;
	struct timer_function * prev;

	bool options;
	int priority;

	unsigned int period; unsigned int temp; void * function_handler;
};

struct timer_structure{

	struct timer_function * function_start;
	unsigned int nr_tcb;

	int priority;

	int function_accumulator;
	unsigned int target;

} function_manager;




#endif /* DARKNESS_DX_TIMERS_H_ */
