/*
 * delay_core.h
 *
 *  Created on: 22 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DELAY_CORE_H_
#define DARKNESS_DX_DELAY_CORE_H_


extern void internal_setup_realtime_clock(void);

/*
 *	Remove Delayed Task from the Operating System
 */
extern void   internal_remove_delay(struct task_ctrl_obj * );					// Remove Task from Delay Queue
/*
 *	Delay Task on Operating System
 */
extern unsigned char  api_delay_task(struct task_ctrl_obj * , int);		// Delay Task

/*
 *	Resume Delayed Task on the Operating System
 */
//extern unsigned char  api_resume_delayed_task(struct task_ctrl_obj * );	// Resume Task

/*
 *	Operating System Task, Processes Delays
 */
extern void   internal_delay_manager(void);										// Kernel Component t service Delays



#endif /* DARKNESS_DX_DELAY_CORE_H_ */
