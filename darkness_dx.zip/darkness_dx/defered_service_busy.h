/*
 * deffered_service_busy.h
 *
 *  Created on: 22 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DEFERED_SERVICE_BUSY_H_
#define DARKNESS_DX_DEFERED_SERVICE_BUSY_H_

#include "stdbool.h"

struct identifier{

	volatile bool status;

	void * handler;
	int argument;

	struct identifier * next;
	struct identifier * prev;
};

struct deferable_manager{

	int nr;
	struct identifier * start;
};

extern void add_deferal(struct identifier * );
extern void remove_deferal(struct identifier * );

extern struct identifier * register_deferal(void *);




#endif /* DARKNESS_DX_DEFERED_SERVICE_BUSY_H_ */
