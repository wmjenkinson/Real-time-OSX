/*
 * deferred_service_core.h
 *
 *  Created on: 22 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DEFERED_SERVICE_CORE_H_
#define DARKNESS_DX_DEFERED_SERVICE_CORE_H_

#include <stdbool.h>
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_busy.h"

struct deferred_service_routine {
	void * handler;
	int arguments;
	struct deferred_service_routine * next_packet;
	struct deferred_service_routine * previous_packet;
};

struct segmented_interrupt_mode {

	unsigned int nr_active;
	unsigned int nr_free;
	struct deferred_service_routine * free_ptr;
	struct deferred_service_routine * start_ptr;

};

extern volatile struct segmented_interrupt_mode deferral_service__controller;


extern void internal_execute_dsr_within_services(void);

extern void internal_execute_dsr_within_interrupts(int);

extern bool internal_execute_dsr_within_exceptions(void);

extern void api_invoke(struct identifier *, int);

extern unsigned char api_configure_dsr_controller(int);

extern void critical_section_exit(void);

#endif /* DARKNESS_DX_DEFERED_SERVICE_CORE_H_ */
