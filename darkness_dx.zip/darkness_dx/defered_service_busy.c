#include "\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_busy.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "stdbool.h"

struct deferable_manager deferal_busy_manager;


void add_deferral(struct identifier * packet);
void add_deferral(struct identifier * packet){

	if( deferal_busy_manager.nr == 0){
		deferal_busy_manager.start	= packet;
		packet->next				= packet;
		packet->prev				= packet;
		deferal_busy_manager.nr		= 1;
	}
	else{
		deferal_busy_manager.nr++;

		packet->next = deferal_busy_manager.start;
		packet->prev = deferal_busy_manager.start->prev;

		deferal_busy_manager.start->prev->next = packet;
		deferal_busy_manager.start->prev = packet;
	}
}

void remove_deferal(struct identifier * packet){

	if( deferal_busy_manager.nr == 1){
		deferal_busy_manager.nr = 0;
	}
	else
	{
		deferal_busy_manager.nr--;
		deferal_busy_manager.start = packet->next;

		packet->prev->next = packet->next;
		packet->next->prev = packet->prev;
	}
}


struct identifier * register_deferal(void * handler){

	struct identifier * id = malloc(sizeof(struct identifier));

	id->handler = handler;
	id->status  = false;

	add_deferral(id);

	return id;
}
