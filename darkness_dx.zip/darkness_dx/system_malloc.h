/*
 * malloc.h
 *
 *  Created on: 20 Aug 2018
 *      Author: wmjen
 */

#ifndef SYSTEM_MALLOC_H_
#define SYSTEM_MALLOC_H_

#include <stddef.h>

extern void * malloc(size_t);
extern void   free(void *);
extern void * calloc(size_t, size_t);
extern void * realloc(void *, size_t);


#endif /* SYSTEM_MALLOC_H_ */
