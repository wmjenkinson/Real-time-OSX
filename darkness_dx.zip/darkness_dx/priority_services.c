#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"



unsigned char internal_resource_retrieve_priority(unsigned char * table);
unsigned char internal_resource_retrieve_priority(unsigned char * table){

	api_system_gateway();
	{

		// BASE EIGHT OPERATIONS

		unsigned char most_significant = KernelUnMapTbl[*(table + _group)];
		unsigned char less_significant = KernelUnMapTbl[*(table + most_significant)];

		unsigned char priority = (most_significant * 8) + less_significant;
		return (priority);
	}
}

/*
 *	Add Priority Level Active to the Operating System Priority Cube
 */
void internal_resource_configure_priority(unsigned char * table, unsigned char priority);
void internal_resource_configure_priority(unsigned char * table, unsigned char priority){

	api_system_gateway();
	{
		// BASE EIGHT OPERATIONS

		unsigned char most_significant = priority / Base8;
		unsigned char less_significant = priority % Base8;

		*(table + most_significant) |= 1 << less_significant;
		*(table + _group) |= (1 << most_significant);
	}
}

/*
 *	Remove Priority Level Active to the Operating System Priority Cube
 */
void internal_resource_unconfigure_priority(unsigned char * table, unsigned char priority);
void internal_resource_unconfigure_priority(unsigned char * table, unsigned char priority){

	api_system_gateway();

	{
		// BASE EIGHT OPERATIONS

		unsigned char most_significant = priority / Base8;
		unsigned char less_significant = priority % Base8;

		*(table + most_significant) &= (0b11111111 - (1 << less_significant));

		if(*(table + most_significant) == 0){
			*(table + _group) &= (0b11111111 - (1 << most_significant)); }
	}
}


