#include "\atmel-software-package-master\examples\getting_started\darkness_dx\port\task.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx/structs.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx/api_gateway.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx/system_malloc.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\name_space.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\signal_library.h"

#include "stddef.h"
#include "string.h"
#include "trace.h"

// Called when a task reaches the end of its function called - know has a Phantom Task
void internal_task_destructor(void);
void internal_task_destructor(void){

//	core_executing_task->application_mode = true;
//	internal_kernel_remove_task(api_ownID());

//	Garbage((void *)core_executing_task->stack_allocation);				// free Task Stack
//	Garbage((void *)core_executing_task);								// free Task Ctrl Block

//	core_execute_task(kernel_scheduler());
}



struct task_ctrl_obj * api_program(void(*task)(void), char const * name, void * variable_pass, unsigned int mpu_mem, unsigned char priority, unsigned char ceiling ){

	api_system_gateway();

	if(priority > 63){
		return(0);
	}

	struct task_ctrl_obj * tcb;

	tcb = malloc(sizeof(struct task_ctrl_obj));			// Allocate Memory for the Task Ctrl Block, used by the Kernel to manage the Task

	if(tcb == NULL){
		return(NULL);
	}




	unsigned int stack;

	// Allocate Memory for the Stack
	tcb->mpu_base_mem_addr = malloc(mpu_mem * sizeof(int));
	tcb->stack_allocation = (unsigned char *)tcb->mpu_base_mem_addr;


	// find the number of bytes allocated
	stack = mpu_mem * sizeof(int);


	if(tcb->mpu_base_mem_addr == NULL){
		free(tcb);
		return(NULL);
	}

	// PointStack to the end of the memory structure, Stack grows downwards
	unsigned int * cpu_core_stack = (unsigned int *)(stack + tcb->mpu_base_mem_addr);

	/* Align stack pointer.                                 */
	cpu_core_stack = (unsigned int *)((unsigned int)(cpu_core_stack) & 0xFFFFFFF8u);

	tcb->task_status = DORMANT;	// Initial State of all Tasks is DORMANT


	/*
	 *	Register task name with operating system
	 */
	tcb->name[0] = '\0';

	//if task name has been specified then load the name into the system
	if(strlen(name)){

		struct task_id * log = malloc(sizeof(struct task_id ));
		log->id = tcb;

		int i = 0;	while(* name != '\0'){

				// copy the name
				tcb->name[i] = * name; log->name[i++] = * name; name++;
		}

		// tidy up strings by nulling the end
		tcb->name[i] = '\0'; log->name[i] = '\0';
		add_system_name(log);
	}


	/*
	 * Signal Setup
	 */
	// Setup Signal Receive Buffer, also associated with TCB
	tcb->signals = malloc(sizeof(struct ipc_signal_sent));
	if(tcb->signals == NULL){

		free(tcb);
		free(tcb->stack_allocation);
		free((struct ipc_signal_obj *)tcb->signal_management);
		return(NULL);
	}

	tcb->signal_management->nr_signal_registered = 0;
	tcb->signals->nr_signal_received = 0;



	/*
	 * Setup tcb priority
	 */
	tcb->delta_priority   = priority;									// Set Task Priority
	tcb->ceiling_priority = ceiling;
	tcb->default_priority = priority;									// Set Base Priority, used by the Priority inversion protocol


	unsigned int program = (unsigned int)task & ~1u; /* Mask off lower bit in case task is thumb mode        */               					   /* Mask off lower bit in case task is thumb mode        */
	/*
	 * Setup general purpose registers
	 */
     * cpu_core_stack-- = (unsigned int) program;										   /* PC                                                    */
     * cpu_core_stack-- = (unsigned int) internal_task_destructor;		                                   /* LR: Supervisor mode                                       */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R12                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R11                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R10				                                           */
     * cpu_core_stack-- = (unsigned int) 0x00000000;		                               /* R9							    		                   */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R8                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;									   /* R7				                                           */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R6                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R5                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R4                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R3                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R2                                                        */
     * cpu_core_stack-- = (unsigned int) 0x00000000;                                       /* R1                                                        */
     * cpu_core_stack-- = (unsigned int) variable_pass;                                    /* R0 ARGUMENT PASS                                         */


	#define  OS_CPU_ARM_BIT_CPSR_MODE_SUPERVISOR 0x13u
	#define  OS_CPU_ARM_BIT_CPSR_T (1u << 5u)

     // Setup Status registers
     if (((unsigned int)task & 0x01u) == 0x01u) {                  			/* See if task runs in Thumb or ARM mode                */
            *cpu_core_stack-- = (OS_CPU_ARM_BIT_CPSR_MODE_SUPERVISOR  		/* Set supervisor mode.                                 */
                     	 	   | OS_CPU_ARM_BIT_CPSR_T);              		/* Set Thumb mode.                                      */
     } else {
            *cpu_core_stack-- = (0x00000100 | OS_CPU_ARM_BIT_CPSR_MODE_SUPERVISOR);
     }



     {	/*
     	 *	Setup Floating Point registers
     	 **/
    	 *cpu_core_stack-- = 0x00000000;	 	/* Initialise Floating point status & control register  */

    	 for (int i = 0; i < 32; i++)
    		 * cpu_core_stack-- = 0x00000000;	/* Initialise general-purpose Floating point registers  */

    	 * cpu_core_stack = 0x40000000;  	 	/* Initialise Floating-Point Exception Register (Enable)*/
     }

    // Insert Newly created task on to the Kernel
	internal_kernel_insert_task(tcb);											// insert task ctrl block unto Kernel Schedular


	tcb->stack_ptr = (unsigned char *)cpu_core_stack;													// Store Stack pointer unto the task ctrl block
	return(tcb);														// Return Handle to the newly Created Task
}
