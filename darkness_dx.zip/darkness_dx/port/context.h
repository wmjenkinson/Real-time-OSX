/*
 * conetxt.h
 *
 *  Created on: 21 Aug 2018
 *      Author: wmjen
 */

#ifndef PORT_CONTEXT_H_
#define PORT_CONTEXT_H_

extern void run (void);
extern void context_switch (void);


#endif /* PORT_CONTEXT_H_ */
