/*
 * interrupt_gateway.h
 *
 *  Created on: 24 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_PORT_INTERRUPT_GATEWAY_H_
#define DARKNESS_DX_PORT_INTERRUPT_GATEWAY_H_

extern void system_gateway(void);

#endif /* DARKNESS_DX_PORT_INTERRUPT_GATEWAY_H_ */
