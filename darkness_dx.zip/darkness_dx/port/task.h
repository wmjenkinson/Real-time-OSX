
#ifndef PORT_TASK_H_
#define PORT_TASK_H_

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

extern struct task_ctrl_obj * api_program(void(*)(void), char const * name, void *, unsigned int, unsigned char, unsigned char);
#endif /* PORT_TASK_H_ */
