

extern struct task_ctrl_obj  * OSTCBHighRdy;
extern struct task_ctrl_obj  * core_executing_task;

void run (void);
__attribute__((naked))void run (void){

	__asm__ __volatile__(

			"MOV     R0, %[current_tcb]\n\t"
		    "MOV     R1, %[tcb_new]\n\t"
		    "LDR     R2, [R1]\n\t"
		    "STR     R2, [R0]\n\t"

		    "LDR     SP, [R2]\n\t"

			"POP     {r0}\n\t"					// Pop new task's FPEXC
            "FLDMIAS SP!, {S0-S31}\n\t"			//    ... Pop new task's General-Purpose floating point registers.
			"POP     {r0}\n\t"
			"VMSR    FPSCR, r0\n\t"				//    ... Pop new task's FPSCR.



		    "LDMFD   SP!, {R0}\n\t"
			"MSR     SPSR_cxsf, R0\n\t"

		    "LDMFD   SP!, {R0-R12, LR, PC}" :: [current_tcb] "r" (&core_executing_task), [tcb_new] "r" (&OSTCBHighRdy));
}


void context_switch (void);
__attribute__((naked))void context_switch (void){

	#define OS_CPU_ARM_CONTROL_THUMB EQU  0x20

	__asm__ __volatile__(
			"STMFD   SP!, {LR}\n\t"			// SAVE CURRENT TASK'S CONTEXT:
			"STMFD   SP!, {LR}\n\t"			// Push return address,
			"STMFD   SP!, {R0-R12}\n\t"		// Push registers,

			"MRS     R0, CPSR\n\t"			// Push current CPSR,

			"TST     LR, #1\n\t"			// See if called from Thumb mode,
			"ORRNE   R0, R0, #0x20\n\t"		// OS_CPU_ARM_CONTROL_THUMB

			"STMFD   SP!, {R0}\n\t"


			"VMRS    r0, FPSCR\n\t"			//     ... Save current FPSCR
			"PUSH    {r0}\n\t"
			"FSTMDBS SP!, {S0-S31}\n\t"		//     ... Save general-purpose floating-point registers.
			"VMRS    r0, FPEXC\n\t"			//     ... Save Floating point exception register.
			"PUSH    {r0}\n\t"


			"CLREX\n\t"						// Clear exclusive monitor.



			"MOV     R0, %[current_tcb]\n\t"	// core_executing_task->StkPtr = SP;
			"LDR     R1, [R0]\n\t"
			"STR     SP, [R1]\n\t"

			"MOV     R0, %[current_tcb]\n\t"
			"MOV     R1, %[tcb_new]\n\t"
			"LDR     R2, [R1]\n\t"
			"STR     R2, [R0]\n\t"

			"LDR     SP, [R2]\n\t"

			"POP     {r0}\n\t"					// Pop new task's FPEXC
			"FLDMIAS SP!, {S0-S31}\n\t"			//    ... Pop new task's General-Purpose floating point registers.
			"POP     {r0}\n\t"
			"VMSR    FPSCR, r0\n\t"				//    ... Pop new task's FPSCR.



			"LDMFD   SP!, {R0}\n\t"
			"MSR     SPSR_cxsf, R0\n\t"

			"LDMFD   SP!, {R0-R12, LR, PC}" :: [current_tcb] "r" (&core_executing_task), [tcb_new] "r" (&OSTCBHighRdy));
}

//	MOV32   R3, OSIntNesting                                    ;   OSIntNesting++;
//	LDRB    R4, [R3]
//	ADD     R4, R4, #1
//	STRB    R4, [R3]

