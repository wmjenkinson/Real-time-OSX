/*
 * ernel_heart_beat.h
 */


#ifndef DARKNESS_DX_PORT_KERNEL_HEART_BEAT_H_
#define DARKNESS_DX_PORT_KERNEL_HEART_BEAT_H_



#include "peripherals/tcd.h"
#include "led/led.h"




#include "\atmel-software-package-master\examples\getting_started\darkness_dx\timers.h"

struct identifier * explorer_id;
struct identifier * timmer_id;

extern struct task_ctrl_obj * test1;

struct _tcd_desc tc = {
	.addr = TC0,
	.channel = 0,
};


static void system_explorer(int argument){

	if((delay_manager->task_status == DORMANT) && (delay_queue.nr_tcb != 0))
		internal_kernel_insert_task(delay_manager);
}

static void system_timers (int argument){

	if((timer_manager->task_status == DORMANT) && (function_manager.nr_tcb != 0))
		internal_kernel_insert_task(timer_manager);
}


/*
 *  Interrupt handler for TC interrupt. Toggles the state of all LEDs except 0
 */
static int _tc_handler(void* arg, void* arg2)
{

	kernel_core.kernel_stamp++;

	// If a task is on the delayed list the then begin processing
	if(delay_queue.target != 0){

		// increment delay_accumulator and if it matches a current delayed task then invoke delayed task
		if(++delay_queue.delay_accumulator >= delay_queue.target){


			api_send_signal(test1, 3);

			// Ready Delay Manager to handle timeout...
			delay_queue.target = 0; api_invoke(explorer_id, 0);
		}
	}



	// Add Time to the Task task_accumulator if Robin Robin is Active
	if(kernel_core.task_round_robin != 0xffffffff){

		// if a context request should be honored then place LSR on the stack, this in itself should lead to a context switch
		if(++delay_queue.task_accumulator > kernel_core.task_round_robin){

			// shutdown processing of round robin time!!!
			kernel_core.task_round_robin = 0xffffffff;

			// trigger round robin
			kernel_core.round_robin_trigger = true; delay_queue.task_accumulator = 0;
		}
	}


	// Handle system timers
	if(function_manager.target != 0){

		if(++function_manager.function_accumulator >= function_manager.target){

			// shutdown processing of timmers
			function_manager.target = 0;

			// run timer manager to process all the timmers
			api_invoke(timmer_id, 0);
		}
	}
	return(0);
}

void start_heartbeat (void);
void start_heartbeat (void){


	explorer_id = register_deferal(system_explorer);
	timmer_id = register_deferal(system_timers);

	tcd_configure_counter(&tc, 0, kernel_tick); /* 4Hz */

	struct _callback _cb;

	callback_set(&_cb, _tc_handler, NULL);
	tcd_start(&tc, &_cb);
}

#endif /* DARKNESS_DX_PORT_KERNEL_HEART_BEAT_H_ */
