#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx/api_gateway.h"
#include "\atmel-software-package-master\examples\getting_started/darkness_dx/priority_services.h"
#include "\atmel-software-package-master\examples\getting_started/darkness_dx/port/context.h"
#include "\atmel-software-package-master\examples\getting_started/darkness_dx/port/task.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\defered_service_core.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\signal_library.h"
#include "\atmel-software-package-master\examples\getting_started\darkness_dx\timers.h"

#include "\atmel-software-package-master\examples\getting_started\darkness_dx/system_specifiers.h"


#include "\atmel-software-package-master\examples\getting_started\darkness_dx/port/kernel_heart_beat.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\semaphore_library.h"


#include "serial/console.h"
#include "trace.h"
#include <stddef.h>
#include "mm/l2cache.h"



// Insert Task Crtl Block unto Priority Queue
unsigned char internal_kernel_insert_task(struct task_ctrl_obj * tcb){


	volatile struct queue_ctrl_object * Queue = (struct queue_ctrl_object *)&kernel_core.priority_levels[tcb->delta_priority];

	int nr_tasks = Queue->nr_tcb;

	if(core_executing_task->delta_priority == tcb->delta_priority){

		if(nr_tasks == 0){
			kernel_core.task_round_robin = 0xffffffff; }
		else{
			delay_queue.task_accumulator = 0;
			kernel_core.task_round_robin = kernel_tick / ((nr_tasks + 1) * TaskGranularity);
		}
	}

	// Obtain Pointer to the Desired Queue that the Task Ctrl Block will be placed on
	//api_system_gateway();
	#ifdef DARKNESSDEBUG
		DebugX.NrTasksRunnning++;
	#endif

	if(!((tcb->task_status == READY) || (tcb->task_status == EXECUTING))){

		if( Queue->nr_tcb == 0){
			Queue->tcb_next_exe	= tcb;
			tcb->tcb_next		= tcb;
			tcb->tcb_prev		= tcb;
			// Mark Priority Level on the Kernel has being ACTIVE
			internal_resource_configure_priority((unsigned char *)&kernel_core.priority_map[0], tcb->delta_priority);
		}
		else{
			tcb->tcb_next = Queue->tcb_next_exe;
			tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
			Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
			Queue->tcb_next_exe->tcb_prev           = tcb;
		} Queue->nr_tcb++;

		if(tcb == core_executing_task){
			tcb->task_status = EXECUTING; }
		else{
			tcb->task_status = READY; }
		return(SUCCESSFUL);
	}
	return(ERROR);
}

// Remove Task Ctrl Block from Kernel Scheduler
unsigned char internal_kernel_remove_task(struct task_ctrl_obj * tcb){

	api_system_gateway()
	// Obtain pointer to desired Priority Level

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksRunnning--;
	#endif

	volatile struct queue_ctrl_object * Queue = (struct queue_ctrl_object *)&kernel_core.priority_levels[tcb->delta_priority];

	int nr_tasks = Queue->nr_tcb;

	if(core_executing_task->delta_priority == tcb->delta_priority){

		if(nr_tasks < 3){
			kernel_core.task_round_robin = 0xffffffff; }
		else{
			delay_queue.task_accumulator = 0;
			kernel_core.task_round_robin = kernel_tick / ((nr_tasks - 1) * TaskGranularity);
		}
	}


	if((tcb->task_status == READY) || (tcb->task_status == EXECUTING)){

		if( Queue->nr_tcb == 1){
			// UnMark Priority Level, no longer in contention for resources
			internal_resource_unconfigure_priority((unsigned char *)&kernel_core.priority_map[0], tcb->delta_priority);
		}
		else
		{
			if(Queue->tcb_next_exe == tcb){
				Queue->tcb_next_exe = tcb->tcb_next;
			}
			tcb->tcb_prev->tcb_next = tcb->tcb_next;
			tcb->tcb_next->tcb_prev = tcb->tcb_prev;
		} Queue->nr_tcb--;

		tcb->task_status = DORMANT;
		return SUCCESSFUL;
	}
	return(ERROR);
}


/* Returns a pointer to the highest ready Task Ctrl Block
   Ready to Run */
struct task_ctrl_obj * kernel_scheduler(void){

	api_system_gateway();

	struct task_ctrl_obj * highest_tcb;		unsigned char priority, nr_tasks;
	struct queue_ctrl_object * highest_qcb;

	// Obtain Current Highest Priority
	priority = internal_resource_retrieve_priority((unsigned char *)&kernel_core.priority_map[0]);

	// no resources are taken up by the Ideal Task, also, it does not compete for resources
	// at priority level 7 unlike other Real-time Kernels such as MicroC/OS.  If it must compete
	// for resources then it will do so at the lowest priority level. However the User is free
	// to change its priority
	highest_qcb = (struct queue_ctrl_object *)&kernel_core.priority_levels[priority];				// Obtain a pointer to the Queue with the highest priority
	highest_tcb = highest_qcb->tcb_next_exe;							// Obtain a pointer to the Highest ready to run Task Ctrl Block

	nr_tasks = highest_qcb->nr_tcb;

	if(nr_tasks == 1){
		kernel_core.task_round_robin = 0xffffffff; }
	else{
		delay_queue.task_accumulator = 0;
		kernel_core.task_round_robin = kernel_tick / (nr_tasks * TaskGranularity);
	}

	highest_qcb->tcb_next_exe = highest_qcb->tcb_next_exe->tcb_next;	// Round Robin, so move the pointer to the next Task Ctrl Block
	return((struct task_ctrl_obj *)highest_tcb);						// return pointer to highest ready Task Ctrl Block
}


static void ideal_task_exe(void){

	while (true){
		asm volatile ("nop");
	}
}

void bios_init(void);
void bios_init(void){

	core_executing_task->application_mode = true;

	l2cache_enable();
	api_configure_dsr_controller(50);

	console_example_info("Getting Started Example");
}


void kernel_init(void);
void kernel_init(void){

	// Global System variables that require initializing
	kernel_core.system_boot = false;

	ideal_task = api_program(ideal_task_exe,"Ideal Task", NULL, 2048, 63, 63);
	delay_manager  = api_program(internal_delay_manager, "Delay Manger", NULL, 4096, 63, 63);
	internal_kernel_remove_task(delay_manager);

	//extern void timer_manager_exe(void);
	timer_manager = api_program(timer_manager_exe, "Timer Manager", NULL, 4096, 63, 63);
	internal_kernel_remove_task(timer_manager);



	struct task_ctrl_obj * taskLoad = kernel_scheduler();

	// initialise memory controller
	memory_controller = api_create_semaphore(1, 0);


	// Ignore Stack Usage - Called Upon the Death of a Task who's stack should have been returned
	taskLoad->task_status = EXECUTING;

	start_heartbeat();

	OSTCBHighRdy = kernel_scheduler();
	core_executing_task->application_mode = false;
	run();

	while(true);
}



unsigned char internal_highest_priority(void){

	// Return a integer indicating the highest priority level active on the Scheduler
	return(internal_resource_retrieve_priority((unsigned char *)&kernel_core.priority_map[0]));
}




struct task_ctrl_obj * api_ownID(void){

	api_system_gateway();

	// return Task TCB identifer that is executing on the Kernel
	return((struct task_ctrl_obj *)core_executing_task);
}


unsigned char internal_task_status_os(struct task_ctrl_obj *tcb);
unsigned char internal_task_status_os(struct task_ctrl_obj *tcb){

	if((tcb->task_status == READY)		||
	   (tcb->task_status == EXECUTING)	||
	   (tcb->task_status == WAITING)	||
	   (tcb->task_status == DORMANT)	||
	   (tcb->task_status == DELAYED)	||
	   (tcb->task_status == EXCEPTION)){
	   	   return(tcb->task_status);
	   }
	// return ERROR, status code not systematic
	return(ERROR);
}


/*
 * Kernel Dispatcher, Darkness Dispatcher used to decided the invoking
 * contest switch required, services must be detected as the TCB associated
 * with a service does not harbor signal structures and thus must be avoided
 * otherwise, if task has signals pending then dispatch the Signal Manager
 */
void internal_hardware_dispatcher(void){

	struct task_ctrl_obj * local_ready_task;

	do{
		kernel_core.round_robin_trigger = false;

		local_ready_task = kernel_scheduler();

		// If a contest switch is going to occur and "should not occur" interrupts are not in use then prepare for contest switch
		if(local_ready_task != core_executing_task){

			// Manage Task Status, if Task was Executing then Set to Ready otherwise Task must have been
			// Suspended, Scheduled on a Resource or otherwise - IGNORE
			if(core_executing_task->task_status == EXECUTING){
				core_executing_task->task_status = READY;
			}
			// Task Being setup to Execute has its task status set to Executing
			local_ready_task->task_status = EXECUTING;

			printf("\n\r%s runing...", local_ready_task->name);

			OSTCBHighRdy = local_ready_task;
			context_switch();
		}

		// Handle Signals received for new task loaded on to the Darkness Kernel
		while(core_executing_task->signals->nr_signal_received != 0){

			// Process pending signals on Readied task
			internal_signal_server((struct task_ctrl_obj *)core_executing_task);
		}

	// If a Other Higher Tasks has become Available during the Contest Switch then Repeat the Contest Switch Procedure
	}while(internal_highest_priority() < core_executing_task->delta_priority);
}



void internal_executive_dispatcher(void){

	// If Link service Routine Pending then process
	if((deferral_service__controller.nr_active != 0) && (core_executing_task->dsr_active == false)){

		// Process and Execute Link service Routines, clobber the memory to ensure registers have been updated
		// after system call to process ISRs , execute_lsr_within_interrupts();
		internal_execute_dsr_within_services();
	}

	// If called during an Link service Routine then do not preform a contest switch - maybe the LSR made a task READY
	if((core_executing_task->dsr_active == false) && (core_executing_task->interrupt_mode == 0)){
		internal_hardware_dispatcher();
	}
}
