	#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
	#include "\atmel-software-package-master\examples\getting_started\darkness_dx\/micro_kernel_core.h"
	#include "\atmel-software-package-master\examples\getting_started\darkness_dx\/api_gateway.h"
	#include "\atmel-software-package-master\examples\getting_started\darkness_dx\/timers.h"
	#include "\atmel-software-package-master\examples\getting_started\darkness_dx\/system_malloc.h"

	#include "trace.h"
	#include "serial/console.h"

/* sorting a link list is quite difficult to achieve, so instead I have decided to
   sort the list has the data is being inserted.
 */

static void link_list_insertion_sort(struct timer_function * new_timer){ api_system_gateway();

	struct timer_function * head, * tial;

	// first link...
	if( function_manager.nr_tcb == 0){

		// tidy start link
		function_manager.function_start	= new_timer;

		new_timer->next = new_timer;
		new_timer->prev = new_timer;

		function_manager.nr_tcb++;
		return;
	}

	// second link, manage start pointer
	else if( function_manager.nr_tcb == 1){

		new_timer->next = function_manager.function_start;
		new_timer->prev = function_manager.function_start;

		function_manager.function_start->next = new_timer;
		function_manager.function_start->prev = new_timer;

		// tidy start link
		if(function_manager.function_start->priority > new_timer->priority)
			function_manager.function_start = new_timer;

		function_manager.nr_tcb++;
		return;
	}

	else{

		head = function_manager.function_start; tial = head->next;

		for(int i = 0; i < function_manager.nr_tcb; i++){

			// quick comparison for links that are equal, less processing
			if(new_timer->priority == head->priority){

				// tidy up starting link
				if((i == 0) && (head->priority > new_timer->priority))
					function_manager.function_start = new_timer;


				new_timer->next = head;
				head->prev->next = new_timer;

				new_timer->prev = head->prev;
				head->prev = new_timer;

				function_manager.nr_tcb++;
				return;
			}

			// test for boundaries insertion
			else if((head->priority < new_timer->priority) && (tial->priority > new_timer->priority)){

				head->next = new_timer;
				new_timer->prev = head;
				new_timer->next = tial;
				tial->prev = new_timer;

				function_manager.nr_tcb++;
				return;
			}

			// could not be placed in the link list, therefore
			// it must be first or last placement
			else if((function_manager.nr_tcb - 1) == i) {

				head = function_manager.function_start;

				// first element in the link list
				if(new_timer->priority < head->priority){

					// tidy start link
					function_manager.function_start = new_timer;

					new_timer->next = head;
					new_timer->prev = head->prev;

					head->prev = new_timer;
					new_timer->prev->next = new_timer;
				}

				// else, last element in link list
				else{

					new_timer->next = head->prev->next;
					head->prev->next = new_timer;
					new_timer->prev = head->prev;
					head->prev = new_timer;
				}

				function_manager.nr_tcb++;
				return;
			}

			// traverse the link list...
			head = head->next; tial = tial->next;
		}
	}
}

static void remove_function_timer(struct timer_function * remove_timer_function){


	if( function_manager.nr_tcb == 1){
		function_manager.nr_tcb = 0;
	}
	else
	{
		function_manager.nr_tcb--;

		if(function_manager.function_start == remove_timer_function){
			function_manager.function_start = remove_timer_function->next;
		}
		remove_timer_function->prev->next = remove_timer_function->next;
		remove_timer_function->next->prev = remove_timer_function->prev;
	}
}




void create_timer(void * function_handler, unsigned int interval, bool options, int priority){

	struct timer_function * new_timer = malloc(sizeof(struct timer_function));

	new_timer->function_handler = function_handler;
	new_timer->period = interval;
	new_timer->temp = interval + function_manager.function_accumulator;

	new_timer->options  = options;
	new_timer->priority = priority;//core_executing_task->delta_priority;

	link_list_insertion_sort(new_timer);

	confirgure_timers();
}


void timer_manager_exe(void){

	int nr_delayed, function_time;

	struct timer_function * timer;
	struct timer_function * timer_next;

	void ( * function_handler )(void);

	do{

		nr_delayed = function_manager.nr_tcb; timer = function_manager.function_start;

		while(nr_delayed-- != 0){		// Travel Delay Queue

			{
				api_system_gateway();
				timer_next = (struct timer_function *)timer->next;


				function_time = timer->temp - function_manager.target;

				// timer expired, handle function call now
				if(function_time <= 0){

					// the link list is sorted by priority therefore the higher priority
					// tasks execute first


					// setup serer priority
					// handle server priority to match function timer priority.
					if(timer->priority != core_executing_task->delta_priority){

						// remove server from execution and update its priority
						internal_kernel_remove_task((struct task_ctrl_obj *)core_executing_task);

						// configure the timer server priority to match the timer function priority
						core_executing_task->delta_priority = timer->priority;

						// insert the timer server back on to kernel execution
						internal_kernel_insert_task((struct task_ctrl_obj *)core_executing_task);

						// handle context switch if required
						if(internal_highest_priority() < core_executing_task->delta_priority)
							internal_executive_dispatcher();
					}


					// get timer function handle
					function_handler = timer->function_handler;

					// call timer function
					function_handler();

					// update timer for repeat mode
					timer->temp = timer->period + function_manager.function_accumulator;

					// timer was one shot
					if(timer->options == ONE_SHOT){

						// remove timer from link list
						remove_function_timer(timer);

						// free memory allocation
						free(timer);
					}

					// handle context switch if required, called timer may have ready'd a task
					if(internal_highest_priority() < core_executing_task->delta_priority)
						internal_executive_dispatcher();
				}
			}
			timer = timer_next;
		}

		{
			api_system_gateway();

			internal_kernel_remove_task(timer_manager);

			confirgure_timers();

			if((timer_manager->task_status == DORMANT) || (internal_highest_priority() < core_executing_task->delta_priority)){
				internal_executive_dispatcher();
			}
		}
	}while(true);
}



void confirgure_timers(void){ api_system_gateway();

	// Stop Delay Processing on the Tick Interrupt
	function_manager.target = 0; int updated_priority = 63;


	int function_accumulator = function_manager.function_accumulator; function_manager.function_accumulator = 0;

	// initialize target
	int local_target = 0;

	// retrieve number of delayed tasks
	int nr_delayed = function_manager.nr_tcb;

	if((nr_delayed == 0) && (core_executing_task != timer_manager)){

		if(timer_manager->task_status != DORMANT){
			internal_kernel_remove_task(timer_manager);
		}
		return;
	}

	// get first delayed task
	struct timer_function * timer = function_manager.function_start;



	// decrement the current running from all the delayed tasks
	for(int i = 0; i < nr_delayed; i++){

		if((timer->temp - function_accumulator) <= 0)
			timer->temp = 0;

		else
			timer->temp -= function_accumulator;

		timer = timer->next;
	}



	for(int i = 0; i < nr_delayed; i++){

		// initialize the first target
		if(i == 0){

			local_target = timer->temp;
			updated_priority = timer->priority;
		}

		else if(timer->temp == local_target){

			if(timer->priority < updated_priority)
				updated_priority = timer->priority;
		}

		// set target to the lowest Timeout
		else if(timer->temp < local_target){

			local_target = timer->temp;
			updated_priority = timer->priority;
		}

		// Traverse the Delayed Lists
		timer = timer->next;
	}

	if(timer_manager->task_status != DORMANT){

		internal_kernel_remove_task(timer_manager);
		timer_manager->delta_priority = updated_priority; internal_kernel_insert_task(timer_manager);
	}


	else if((local_target == 0) && (timer_manager->task_status == DORMANT) && (function_manager.nr_tcb != 0))
		internal_kernel_insert_task(timer_manager);


	// Configure new target specifications
	timer_manager->delta_priority = updated_priority;
	function_manager.target = local_target;
}

