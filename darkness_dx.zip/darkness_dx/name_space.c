#include <string.h>
#include <stddef.h>


#include "\atmel-software-package-master\examples\getting_started\darkness_dx\name_space.h"



struct name name_space;
/*
 *	store task identification and name in system link list
 */
void add_system_name(struct task_id * name_log){

	if( name_space.nr++ == 0){
		name_space.first	= name_log;
		name_log->next		= name_log;
		name_log->prev		= name_log;
	}
	else{
		name_log->next = name_space.first;
		name_log->prev = name_space.first->prev;

		name_space.first->prev->next = name_log;
		name_space.first->prev = name_log;
	}
}


/*
 *	reemove task identification and name in system link list
 */
void remove_system_name(struct task_id * name_log){


	if( name_space.nr == 1){
		name_space.nr = 0;
	}
	else
	{
		name_space.nr--;
		if(name_space.first == name_log){
			name_space.first = name_log->next;
		}
		name_log->prev->next = name_log->next;
		name_log->next->prev = name_log->prev;
	}
}


/*
 *	get task identification from system link list
 */
struct task_ctrl_obj * get_task_id(char const * name){

	struct task_id * tmp_name = name_space.first;

	for(int i = 0; i < name_space.nr; i++){

		// if size of name matches that on the link list the test
		if(strlen(name) == strlen(&tmp_name->name[0])){

			// if the names match then return task control block addresss
			if(memcmp(name, &tmp_name->name[0], strlen(name)) == 0){
				return(tmp_name->id);
			}
		}
		tmp_name = tmp_name->next;
	}
	return (NULL);
}


/*
 *	get task name from system link list
 */
char * get_task_name(struct task_ctrl_obj * tcb){


	struct task_id * tmp_name = name_space.first;

	for(int i = 0; i < name_space.nr; i++){

		// if task control blocks address match then return a pointer to name string
		if(tcb == tmp_name->id){

			return(&tmp_name->name[0]);
		}
		tmp_name = tmp_name->next;
	}
	return (NULL);
}



/*
 *	get task name from system link list
 */
struct task_id * get_log_file(struct task_ctrl_obj * tcb){


	struct task_id * tmp_name = name_space.first;

	for(int i = 0; i < name_space.nr; i++){

		// if task control blocks address match then return a pointer to name string
		if(tcb == tmp_name->id){

			return(tmp_name);
		}
		tmp_name = tmp_name->next;
	}
	return (NULL);
}
