/*
 * pages.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_PAGES_H_
#define DARKNESS_DX_DARKNESS_API_PAGES_H_



struct page_manager {
	unsigned char type;
	unsigned int nr_buffers;
	char start_death_process;
	char brownout;
	unsigned char theshold;
	unsigned char granularity;
	unsigned int size;
	unsigned int avaialble_resourses;
	struct ipc_buffer_object * next_buffer;
};




extern struct page_manager * api_setup_pages(unsigned short int, unsigned short int, unsigned char, unsigned char, unsigned char, char);

extern void api_brownout_protection(struct page_manager *, char);
extern void api_kill_page_setup(struct page_manager *);

extern void internal_combine_pages(struct page_manager *,  struct ipc_buffer_object *);
extern void api_return_buffer(struct page_manager *,  struct ipc_buffer_object *);
extern struct ipc_buffer_object * api_alloc_buffer(struct page_manager *);





#endif /* DARKNESS_DX_DARKNESS_API_PAGES_H_ */
