/*
 * pipes_library.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_PIPES_LIBRARY_H_
#define DARKNESS_DX_DARKNESS_API_PIPES_LIBRARY_H_



#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

struct token_ctrl_bit {
	struct token_ctrl_bit * next_token;
	struct token_ctrl_bit * prev_token;
	char datum;
};

struct token_ctrl_8bit {
	struct token_ctrl_8bit * next_token;
	struct token_ctrl_8bit * prev_token;
	unsigned char datum;
};

struct token_ctrl_16bit {
	struct token_ctrl_16bit * next_token;
	struct token_ctrl_16bit * prev_token;
	unsigned short int datum;
};

struct token_ctrl_32bit {
	struct token_ctrl_32bit * next_token;
	struct token_ctrl_32bit * prev_token;
	unsigned int datum;
};

struct token_ctrl_64bit {
	struct token_ctrl_64bit * next_token;
	struct token_ctrl_64bit * prev_token;
	unsigned long long int datum;
};

struct ipc_pipe_object {							// Resource Ctrl is used by, Nodes, buffer, Semaphores, Futexs, Mutex's
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;						// Semaphore Counter

	struct token_ctrl_32bit * free_token;
	unsigned int nr_tokens;

	struct token_ctrl_bit   * data_flow_1bit;		// Node Tokens
	struct token_ctrl_8bit  * data_flow_8bit;		// Node Tokens
	struct token_ctrl_16bit * data_flow_16bit;		// Node Tokens
	struct token_ctrl_32bit * data_flow_32bit;		// Node Tokens
	struct token_ctrl_64bit * data_flow_64bit;		// Node Tokens
};

/*
 *	Insert Task onto the Pipeline Waiting List
 */
extern unsigned char internal_pipe_insert_task(struct ipc_pipe_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

/*
 *	Remove Task from the PipeLine waiting List
 */
extern unsigned char internal_pipe_remove_task(struct ipc_pipe_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

/*
 *	Retrieve Highests, and FIFO Task from the Pipeline
 */
extern struct task_ctrl_obj * internal_pipe_scheduler(struct ipc_pipe_object *);						// Return TCB to highest task on resource

/* Nodes are small messages passed within an Application api_program Interface, of important note is that
   they will overwrite any previous data on the node. */
extern struct ipc_pipe_object *		api_create_pipe(void);												// Create Node
extern unsigned char					api_delete_pipe(struct ipc_pipe_object *);							// Delete Node
extern unsigned char					api_send_to_pipe(struct ipc_pipe_object *, unsigned int);			// Produce a token on a Node
extern unsigned char					api_broadcast_on_pipe(struct ipc_pipe_object *, unsigned int);		// BroadcaSt a token to all tasks waiting on a node
extern unsigned int					api_recieve_pipe(struct ipc_pipe_object *, unsigned short int);		// Consume a token on a Node
extern unsigned int					api_accept_pipe(struct ipc_pipe_object *);							// Accept a Token if available


/*
 *	Set aside Memory for the Pipeline/Tokens
 */
extern unsigned char configure_token_controller(struct ipc_pipe_object * pipe, int nr_tokens);

/*
 *	Return Token to the Pipeline freeing it for further use
 */
extern void return_token(struct ipc_pipe_object * pipe, struct token_ctrl_32bit * token);

/*
 *	Obtain Token from the Pipeline
 */
extern struct token_ctrl_32bit * allocate_token(struct ipc_pipe_object * pipe);

/*
 *	INTERNAL SYSTEM - For Placing Data into the Pipe
 */
extern void pump_data(struct ipc_pipe_object *, unsigned int);

/*
 *	INTERNAL PERATION - For Obtaing Data from Pipe
 */
extern unsigned int retrieve_data(struct ipc_pipe_object *);




#endif /* DARKNESS_DX_DARKNESS_API_PIPES_LIBRARY_H_ */
