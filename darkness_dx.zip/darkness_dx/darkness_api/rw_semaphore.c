

/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 *
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * semaphore_library.c
 *
 * Created: 17/09/2015 20:44:32
 *  Author: wmjen
 */

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\rw_semaphore.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"

#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>


struct ipc_semaphore_object_rw {
	struct queue_ctrl_object rw_queue;
	int readers;
	int writers;
	bool writing;
};
/*
 *	Insert Task unto the Semaphores waiting list
 */
unsigned char internal_rw_semaphore_insert_task(struct ipc_semaphore_object_rw *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

/*
 *	Remove Task from the Semaphores waiting List
 */
unsigned char internal_rw_semaphore_remove_task(struct ipc_semaphore_object_rw *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

/*
 *	Schedule Highest and FIFO Task on the Semaphores witing List
 */
struct task_ctrl_obj * internal_rw_semaphore_scheduler(struct ipc_semaphore_object_rw *);				// Return TCB to highest task on resource


struct ipc_semaphore_object_rw * api_create_rw_semaphore(void);			// Create Semaphore
unsigned char  api_delete_rw_semaphore(struct ipc_semaphore_object_rw *);						// Delete Semaphore

unsigned char api_read_semaphore(struct ipc_semaphore_object_rw *, unsigned int );
unsigned char api_write_semaphore(struct ipc_semaphore_object_rw *, unsigned int);

unsigned char api_post_rd_semaphore(struct ipc_semaphore_object_rw *);
unsigned char api_post_wr_semaphore(struct ipc_semaphore_object_rw *);

unsigned char api_read_semaphore_preference(struct ipc_semaphore_object_rw *, unsigned int);



struct ipc_semaphore_object_rw * api_create_rw_semaphore(void){

	api_system_gateway();
	struct ipc_semaphore_object_rw * rw_semaphore;

	rw_semaphore = malloc(sizeof(struct ipc_semaphore_object_rw));	// allocate storage for Semaphore
	if(rw_semaphore == NULL){
		//print_dbg("Error Allocating Memory for a Semaphore\n\r");
		return(NULL);
	}

	rw_semaphore->rw_queue.nr_tcb	= 0;
	return(rw_semaphore);
}

/*
 *	Delete Semaphore, return memory to the Heap
 */
unsigned char api_delete_rw_semaphore(struct ipc_semaphore_object_rw * rw_semaphore){

	api_system_gateway();

	struct task_ctrl_obj * tcb;

	while(rw_semaphore->rw_queue.nr_tcb != 0){		// if deleting resource a tasks pending on
		tcb = internal_rw_semaphore_scheduler(rw_semaphore);			// resource then ready tasks

		if(tcb->delay_counter != Zero)					// if tasks also delayed then remove from
			internal_remove_delay(tcb);							// the delay queue

		internal_rw_semaphore_remove_task(rw_semaphore, tcb);			// remove from the resource

		tcb->internal_ctrl = EXCEPTION;					// set task status to EXCEPTION
		internal_kernel_insert_task(tcb);						// Insert task unto Kernel Scheduler
		}

	free(rw_semaphore);									// free Semaphore Memory

	return(SUCCESSFUL);									// and return SUCCCESSFUL
}

/* Pend on Semaphore if it is not available with an optional timeout
   value passed in the delay field */
unsigned char api_read_semaphore(struct ipc_semaphore_object_rw * rw_semaphore, unsigned int delay){

	api_system_gateway();
	struct task_ctrl_obj * tcb;


	extern unsigned char internal_kernel_remove_task(struct task_ctrl_obj *);

	if((rw_semaphore->writers == 0) && (rw_semaphore->writing == false)){		// If Semaphore count not equal zero then it is
		rw_semaphore->readers++;												// available and return and return Semaphore ACK
		return(SEM_ACK);
	}
	else{
		// Else delay task unto Semphore prority queue
		tcb = (struct task_ctrl_obj *)core_executing_task;
		tcb->sem_rw_type = 0;

		internal_kernel_remove_task(tcb);							// remove task from kernel scheduler
		internal_rw_semaphore_insert_task(rw_semaphore, tcb);				// insert task unto Semaphore priority queue

		if(delay != 0){										// if optional delay timeout specified then
			api_delay_task(tcb, delay);							// delay task
		}

		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		asm volatile ("" ::: "memory");
	}

	tcb = (struct task_ctrl_obj *)core_executing_task;

	// If Task Delayed then remove from the Delay List
	if(tcb->delay_counter != 0){
		internal_remove_delay(tcb);
	}


	if(tcb->internal_ctrl == TIMEOUT){
		tcb->internal_ctrl = acknowledge;
		return(TIMEOUT);
	}
	else{
		return(SEM_ACK);				// HOOK, return status after pend completes
	}
}


unsigned char api_write_semaphore(struct ipc_semaphore_object_rw * rw_semaphore, unsigned int delay){

	api_system_gateway();
	struct task_ctrl_obj * tcb;


	extern unsigned char internal_kernel_remove_task(struct task_ctrl_obj *);

	if((rw_semaphore->rw_queue.nr_tcb == 0) && (rw_semaphore->writing == false) && (rw_semaphore->readers == 0)){		// If Semaphore count not equal zero then it is
		rw_semaphore->writing = true;				// available and return and return Semaphore ACK
		return(SEM_ACK);
	}
	else{
		// Else delay task unto Semphore prority queue
		tcb = (struct task_ctrl_obj *)core_executing_task;

		tcb->sem_rw_type = 1; rw_semaphore->writers++;

		internal_kernel_remove_task(tcb);							// remove task from kernel scheduler
		internal_rw_semaphore_insert_task(rw_semaphore, tcb);				// insert task unto Semaphore priority queue

		if(delay != 0){										// if optional delay timeout specified then
			api_delay_task(tcb, delay);							// delay task
		}

		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		barrier();
	}

	tcb = (struct task_ctrl_obj *)core_executing_task;

	// If Task Delayed then remove from the Delay List
	if(tcb->delay_counter != 0){
		internal_remove_delay(tcb);
	}


	if(tcb->internal_ctrl == TIMEOUT){
		tcb->internal_ctrl = acknowledge;
		return(TIMEOUT);
	}
	else{
		return(SEM_ACK);				// HOOK, return status after pend completes
	}
}

/*
 *	Preform a Post Operation on the Semaphore
 */
unsigned char api_post_rd_semaphore(struct ipc_semaphore_object_rw * rw_semaphore){
	api_system_gateway();


	struct task_ctrl_obj * tcb;
	if((--rw_semaphore->readers == 0) && (rw_semaphore->rw_queue.nr_tcb != 0)){	// if task waiting on Semaphore then Ready the


		tcb = internal_rw_semaphore_scheduler(rw_semaphore);		// the highest to run task

		rw_semaphore->writing = true; rw_semaphore->writers--;

		if(tcb->delay_counter != Zero){				// if task has a timeout specified then remove
			internal_remove_delay(tcb);						// from the delay queue
		}

		internal_rw_semaphore_remove_task(rw_semaphore, tcb);		// remove the task from the resource
		internal_kernel_insert_task(tcb);					// insert onto the Kernel Scheduler

		tcb->internal_ctrl = SEM_ACK;				// Set HOOK status to SEM_ACK

		if(tcb->delta_priority < core_executing_task->delta_priority){	// Test if Context swicth required after readying
			internal_executive_dispatcher();

			// There is another mechanism which can be used to achieve something similar: memory barriers.
			// This is accomplished through adding a special "memory" clobber to the assembler statement,
			// and ensures that all variables are flushed from registers to memory before the statement,
			// and then re-read after the statement.
			barrier();
		}
	}
	return(SUCCESSFUL);	// Return SUCCESSFUL
}

unsigned char api_post_wr_semaphore(struct ipc_semaphore_object_rw * rw_semaphore){
	api_system_gateway();


	struct task_ctrl_obj * tcb;
	if(rw_semaphore->rw_queue.nr_tcb != 0){	// if task waiting on Semaphore then Ready the


		tcb = internal_rw_semaphore_scheduler(rw_semaphore);		// the highest to run task

		// if next up is a reader then ready all readers
		if(tcb->sem_rw_type == 0){

			// ready all readers
			for(int i = 0; i < rw_semaphore->rw_queue.nr_tcb; i++){

				if(tcb->sem_rw_type == 0){

					if(tcb->delay_counter != Zero){				// if task has a timeout specified then remove
						internal_remove_delay(tcb);						// from the delay queue
					}

					internal_rw_semaphore_remove_task(rw_semaphore, tcb);		// remove the task from the resource
					internal_kernel_insert_task(tcb);					// insert onto the Kernel Scheduler

					rw_semaphore->readers++;
					tcb->internal_ctrl = SEM_ACK;				// Set HOOK status to SEM_ACK
				}tcb = internal_rw_semaphore_scheduler(rw_semaphore);
			}

			if(tcb->delta_priority < core_executing_task->delta_priority){	// Test if Context swicth required after readying
				internal_executive_dispatcher();

				// There is another mechanism which can be used to achieve something similar: memory barriers.
				// This is accomplished through adding a special "memory" clobber to the assembler statement,
				// and ensures that all variables are flushed from registers to memory before the statement,
				// and then re-read after the statement.
				barrier();
			}
		}
		else{

			if(tcb->delay_counter != Zero){				// if task has a timeout specified then remove
				internal_remove_delay(tcb);						// from the delay queue
			}

			internal_rw_semaphore_remove_task(rw_semaphore, tcb);		// remove the task from the resource
			internal_kernel_insert_task(tcb);					// insert onto the Kernel Scheduler

			rw_semaphore->writers--; rw_semaphore->writing = true;
			tcb->internal_ctrl = SEM_ACK;				// Set HOOK status to SEM_ACK
		}
	}
	return(SUCCESSFUL);	// Return SUCCESSFUL
}

/* Pend on Semaphore if it is not available with an optional timeout
   value passed in the delay field */
unsigned char api_read_semaphore_preference(struct ipc_semaphore_object_rw * rw_semaphore, unsigned int delay){

	api_system_gateway();
	struct task_ctrl_obj * tcb;


	extern unsigned char internal_kernel_remove_task(struct task_ctrl_obj *);

	if((rw_semaphore->readers != 0) || (rw_semaphore->rw_queue.nr_tcb == 0)){		// If Semaphore count not equal zero then it is
		rw_semaphore->readers++;				// available and return and return Semaphore ACK
		return(SEM_ACK);
	}
	else{
		// Else delay task unto Semphore prority queue
		tcb = (struct task_ctrl_obj *)core_executing_task;
		tcb->sem_rw_type = 0;

		internal_kernel_remove_task(tcb);							// remove task from kernel scheduler
		internal_rw_semaphore_insert_task(rw_semaphore, tcb);				// insert task unto Semaphore priority queue

		if(delay != 0){										// if optional delay timeout specified then
			api_delay_task(tcb, delay);							// delay task
		}

		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		barrier();
	}

	tcb = (struct task_ctrl_obj *)core_executing_task;

	// If Task Delayed then remove from the Delay List
	if(tcb->delay_counter != 0){
		internal_remove_delay(tcb);
	}


	if(tcb->internal_ctrl == TIMEOUT){
		tcb->internal_ctrl = acknowledge;
		return(TIMEOUT);
	}
	else{
		return(SEM_ACK);				// HOOK, return status after pend completes
	}
}



																// Wait List
/* Return pointer to Highest Priority Task Ctrl Block */
struct task_ctrl_obj * internal_rw_semaphore_scheduler(struct ipc_semaphore_object_rw * resource){

	api_system_gateway();
	return((struct task_ctrl_obj *)resource->rw_queue.tcb_next_exe);
}

/* Insert task Ctrl Block of Resource Priority Pending List */
unsigned char internal_rw_semaphore_insert_task(struct ipc_semaphore_object_rw * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	tcb->resource_waiting = (void *)resource;

	struct queue_ctrl_object * Queue = &resource->rw_queue;

	tcb->task_status = SEMAPHORE_WAITING;

	if( Queue->nr_tcb == Zero){
		Queue->tcb_next_exe	= tcb;
		tcb->tcb_next		= tcb;
		tcb->tcb_prev		= tcb;
		Queue->nr_tcb		= 1;
	}
	else{
		Queue->nr_tcb++;
		tcb->tcb_next = (struct task_ctrl_obj *)Queue->tcb_next_exe;
		tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
		Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
		Queue->tcb_next_exe->tcb_prev = tcb;
	}
	return(SUCCESSFUL);
}

/* Remove Task ctrl Block from Resourse Pending List */
unsigned char internal_rw_semaphore_remove_task(struct ipc_semaphore_object_rw * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();

	if(tcb->task_status != SEMAPHORE_WAITING){ return ERROR; }

	tcb->task_status		= DORMANT;
	tcb->internal_ctrl		= DORMANT;
	tcb->resource_waiting	= NULL;

	 struct queue_ctrl_object * Queue = &resource->rw_queue;

	if( Queue->nr_tcb == 1){
		Queue->nr_tcb = 0;           // Unmark Priority Map
	}
	else
	{
		Queue->nr_tcb--;
		if(Queue->tcb_next_exe == tcb){
			Queue->tcb_next_exe = tcb->tcb_next;
		}
		tcb->tcb_prev->tcb_next = tcb->tcb_next;
		tcb->tcb_next->tcb_prev = tcb->tcb_prev;
	}
	return(SUCCESSFUL);
}



