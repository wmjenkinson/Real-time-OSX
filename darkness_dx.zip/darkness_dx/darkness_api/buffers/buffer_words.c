
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_utilities.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_words.h"

struct ipc_buffer_object * api_create_buffer( unsigned short int);						// Create buffer
unsigned char api_delete_buffer(struct ipc_buffer_object * );				// Delete buffer
unsigned char api_post_to_buffer(struct ipc_buffer_object * ,  unsigned int);		// Post Data to buffer
//unsigned char api_post_to_front(struct ipc_buffer_object * ,  unsigned int);		// Post to Front of buffer
unsigned char api_broadcast_to_buffer(struct ipc_buffer_object * ,  unsigned int);// Broadcast to All Task waiting on buffer
unsigned int api_pend_on_buffer(struct ipc_buffer_object * ,  unsigned short int,  unsigned char *);		// Accept Data Else Wait and or Delay
unsigned int api_buffer_accept(struct ipc_buffer_object * ,  unsigned char *);				// Accept Data if Available
unsigned char api_buffer_flush(struct ipc_buffer_object * );				// Flush Data



#include <stddef.h>

struct ipc_buffer_object * api_create_buffer( unsigned short int buffer_size){					// Create buffer

	api_system_gateway();
	struct ipc_buffer_object    * system_ctrl;									// buffer Structure
	struct buffer		 * buffer_ctrl;										// buffer Holder

	system_ctrl = api_malloc(sizeof(struct ipc_buffer_object));						// Allocate buffer Structure
	if(system_ctrl == NULL){
		//print_dbg("Error Allocating buffer");
		return(NULL);
	}

	buffer_ctrl	= api_malloc(sizeof(struct buffer));							// Allocate buffer Header
	if(buffer_ctrl == NULL){
		//print_dbg("Error Allocating buffer");
		api_free(system_ctrl);
		return(NULL);
	}

	system_ctrl->type	      = DWORD;									// Set Resource to buffer type
	system_ctrl->ipc_resource = Zero;
	system_ctrl->buffer_object_ptr = buffer_ctrl;							// buffer Structure Associated With buffer
	system_ctrl->buffer_size = buffer_size;

	system_ctrl->buffer_object_ptr->buffer_start = api_malloc(buffer_size * sizeof(unsigned int));							// Allocate and Initailise buffer, Start Points to Start

	if(system_ctrl->buffer_object_ptr->buffer_start == NULL){
		//print_dbg("Error Allocating buffer");

		api_free(system_ctrl);
		api_free(buffer_ctrl);

		return(NULL);
	}


	system_ctrl->buffer_object_ptr->buffer_end   = buffer_ctrl->buffer_start + buffer_size - 1;		// End Points to End
	system_ctrl->buffer_object_ptr->buffer_in    = buffer_ctrl->buffer_start;					// In and Out Initialised
	system_ctrl->buffer_object_ptr->buffer_out   = buffer_ctrl->buffer_start;

	return((struct ipc_buffer_object *)system_ctrl);													// Return Handle to buffer
}


unsigned char api_delete_buffer(struct ipc_buffer_object *  buffer_ctrl){						// Delete buffer

	api_system_gateway();
	if(buffer_ctrl->type != DWORD){
		return(ERROR);
	}

	struct task_ctrl_obj * tcb;

	while(buffer_ctrl->priority_map[_group] != EMPTY){								// If Tasks WAITING on buffer Structure
		tcb = internal_buffer_scheduler(buffer_ctrl);									// Then free Tasks from Structures
		if(tcb->delay_counter != Zero){									// if task is also delayed then remove from
			internal_remove_delay(tcb);
		}												// delay queue
		internal_buffer_remove_task(buffer_ctrl, tcb);										// Remove Each Task from Resource Structure
		tcb->task_status = EXCEPTION;										// Inform Task that an EXCEPTION has Occured
		internal_kernel_insert_task(tcb);											// Make Task READY to Run
	}

	api_free((unsigned int *)buffer_ctrl->buffer_object_ptr->buffer_start);						// free buffer
	api_free((struct buffer *)buffer_ctrl->buffer_object_ptr);									// free buffer Handler
	api_free((struct ipc_buffer_object *)buffer_ctrl);									// Finally free Resource

	return(SUCCESSFUL);														// Return SUCCESSFUL
}

unsigned char api_post_to_buffer(struct ipc_buffer_object *  buffer_ctrl,  unsigned int message){		// Post Data To buffer

	api_system_gateway();
	if(buffer_ctrl->type != DWORD){
		return(ERROR);
	}

	struct task_ctrl_obj * tcb;

	if(buffer_ctrl->priority_map[_group] != EMPTY){											// If Task WAITING on Data then make READY and Supply Data
		tcb = internal_buffer_scheduler(buffer_ctrl);											// Obtain Highest Task

		if(tcb->delay_counter != Zero){												// If Task was DELAYED WAITING
			internal_remove_delay(tcb);														// Then Remove from Delay buffer
		}
		internal_buffer_remove_task(buffer_ctrl, tcb);												// Remove from Resource buffer
		internal_kernel_insert_task(tcb);													// Insert unto Kernel, i.e. READY task

		tcb->datum_return = (void *)message;												// Supply Data to Task

		if(internal_highest_priority() < core_executing_task->delta_priority){				// If Task Readyied is of Higher Priority then
			internal_executive_dispatcher();

			// There is another mechanism which can be used to achieve something similar: memory barriers.
			// This is accomplished through adding a special "memory" clobber to the assembler statement,
			// and ensures that all variables are flushed from registers to memory before the statement,
			// and then re-read after the statement.
			barrier();
		}
	}
	else{
		if(buffer_ctrl->ipc_resource != buffer_ctrl->buffer_size){
			buffer_ctrl->ipc_resource++;
		}
		*buffer_ctrl->buffer_object_ptr->buffer_in = message;									// Insert Data
		if(buffer_ctrl->buffer_object_ptr->buffer_in == buffer_ctrl->buffer_object_ptr->buffer_end){		// If at the End of the buffer then WRAP Around
			buffer_ctrl->buffer_object_ptr->buffer_in = buffer_ctrl->buffer_object_ptr->buffer_start;
		}
		else{
			buffer_ctrl->buffer_object_ptr->buffer_in++;										// If not at the End of the buffer then Increment IN Ptr
		}
	}
	return(SUCCESSFUL);																// Else Return SUCCESSFUL
}

unsigned char api_broadcast_to_buffer(struct ipc_buffer_object *  buffer_ctrl,  unsigned int message){		// Broadcast Token to all WAITING Tasks else store token

	api_system_gateway();
	if(buffer_ctrl->type != DWORD){
		return(ERROR);
	}

	struct task_ctrl_obj * tcb;

	if(buffer_ctrl->priority_map[_group] != EMPTY){											// If Tasks WAITING then make READY and give Token to Each Task
		while(buffer_ctrl->priority_map[_group] != EMPTY){
			tcb = internal_buffer_scheduler(buffer_ctrl);										// Start with the highest Task first

			if(tcb->delay_counter != Zero){											// If Task DELAYED then remove from Delay Queue
				internal_remove_delay(tcb);
			}

			internal_buffer_remove_task(buffer_ctrl, tcb);											// Remove Task of Resource
			internal_kernel_insert_task(tcb);												// Insert unto Kernel
			tcb->datum_return = (void *)message;											// and hand Token to Task
		}
		if(internal_highest_priority() < core_executing_task->delta_priority){				// If Task READIED, check Scheduler for HIGHEST Task READY to Run
			internal_executive_dispatcher();

			// There is another mechanism which can be used to achieve something similar: memory barriers.
			// This is accomplished through adding a special "memory" clobber to the assembler statement,
			// and ensures that all variables are flushed from registers to memory before the statement,
			// and then re-read after the statement.
			barrier();
		}
	}
	else{
		buffer_ctrl->ipc_resource++;
		*buffer_ctrl->buffer_object_ptr->buffer_in = message;									// Else no tasks WAITING so Insert Data
		if(buffer_ctrl->buffer_object_ptr->buffer_in == buffer_ctrl->buffer_object_ptr->buffer_end){		// If at the End of the buffer then WRAP Around
			buffer_ctrl->buffer_object_ptr->buffer_in = buffer_ctrl->buffer_object_ptr->buffer_start;
		}
		else{
			buffer_ctrl->buffer_object_ptr->buffer_in++;									// If not at the End of the buffer then Increment IN Ptr
		}
	}
	return(SUCCESSFUL);																		// Return SUCCESSFUL
}


unsigned int api_pend_on_buffer(struct ipc_buffer_object *  buffer_ctrl,  unsigned short int delay_length,  unsigned char *status){					// Pend on buffer if no token available

	api_system_gateway();
	if(buffer_ctrl->type != DWORD){
		return(ERROR);
	}

	unsigned int buf_token;

	struct task_ctrl_obj * tcb = (struct task_ctrl_obj *)core_executing_task;

	if(buffer_ctrl->ipc_resource != Zero){													// Counter not Zero then data is on the buffer
		buffer_ctrl->ipc_resource--;														// Decrement counter
		buf_token = *buffer_ctrl->buffer_object_ptr->buffer_out;								// Obtain Token
		if(buffer_ctrl->buffer_object_ptr->buffer_out == buffer_ctrl->buffer_object_ptr->buffer_end){	// Handle WRAP around
			buffer_ctrl->buffer_object_ptr->buffer_out = buffer_ctrl->buffer_object_ptr->buffer_start;
		}
		else{
			buffer_ctrl->buffer_object_ptr->buffer_out++;									// Increment Out position
		}
		*status = SUCCESSFUL;
		return(buf_token);																	// Return Token to caller
	}
	else{

		//	if(kernel_core.interrupt_service_routine != 0){
		//		return(ACCESS_DENIED);
		//	}
		// Else no Data on buffer, Pend Task
		internal_kernel_remove_task(tcb);											// Remove from Kernel
		internal_buffer_insert_task(buffer_ctrl, tcb);				// Insert Task unto Reourse WAIT List

		if(delay_length != 0){																// If Delay Value Specified then also Insert Task unto Delay List
			api_delay_task(tcb, delay_length);
		}

		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		barrier();

		if(tcb->internal_ctrl == TIMEOUT){
			tcb->internal_ctrl = acknowledge;
			*status = EMPTY;
			return((unsigned int)TIMEOUT);
		}
		else{
			*status = SUCCESSFUL;
			return((unsigned int)tcb->datum_return);																// When Tsak is re-initalised unto KErnel it will find itself here
		}
	}
}


unsigned int api_buffer_accept(struct ipc_buffer_object *  buffer_ctrl,  unsigned char *status){

	api_system_gateway();
	if(buffer_ctrl->type != DWORD){
		return(ERROR);
	}

	unsigned int datum = 0; *status = EMPTY;

	if(buffer_ctrl->ipc_resource != Zero){
		buffer_ctrl->ipc_resource--;
		datum = *buffer_ctrl->buffer_object_ptr->buffer_out;
		*status = SUCCESSFUL;

		if(buffer_ctrl->buffer_object_ptr->buffer_out == buffer_ctrl->buffer_object_ptr->buffer_end){
			buffer_ctrl->buffer_object_ptr->buffer_out = buffer_ctrl->buffer_object_ptr->buffer_start;
		}
		else{
			buffer_ctrl->buffer_object_ptr->buffer_out++;
		}
	}
	return(datum);
}

unsigned char api_buffer_flush(struct ipc_buffer_object *  buffer_ctrl){

	api_system_gateway();
	if(buffer_ctrl->type != DWORD){
		return(ERROR);
	}

	buffer_ctrl->ipc_resource = 0;
	buffer_ctrl->buffer_object_ptr->buffer_in = buffer_ctrl->buffer_object_ptr->buffer_start;
	buffer_ctrl->buffer_object_ptr->buffer_out = buffer_ctrl->buffer_object_ptr->buffer_start;

	return(SUCCESSFUL);
}
