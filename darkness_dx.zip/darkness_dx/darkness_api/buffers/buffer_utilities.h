/*
 * buffer_utilities.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_BUFFERS_BUFFER_UTILITIES_H_
#define DARKNESS_DX_DARKNESS_API_BUFFERS_BUFFER_UTILITIES_H_



#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_bytes.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_shorts.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_words.h"


/* IPC COre handles the common interface between Resources, such has
   Semaphore, Buffer, Nodes and mailboxs */
extern unsigned char internal_buffer_insert_task(struct ipc_buffer_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list
extern unsigned char internal_buffer_remove_task(struct ipc_buffer_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list
extern struct task_ctrl_obj * internal_buffer_scheduler(struct ipc_buffer_object *);				// Return TCB to highest task on resource




#endif /* DARKNESS_DX_DARKNESS_API_BUFFERS_BUFFER_UTILITIES_H_ */
