#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

struct ipc_buffer_object {							// Resource Ctrl is used by, Nodes, buffer, Semaphores, Futexs, Mutex's

	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING

	unsigned char type;
	unsigned int ipc_resource;						// resource counter such as the number of Semaphore Counter

	struct buffer   * buffer_object_ptr;			// Points to buffer memory
	struct buffer8  * buffer_object_ptr8;
	struct buffer16 * buffer_object_ptr16;

	unsigned int buffer_size;

	struct ipc_buffer_object * next;				// Next and Previous Used to Maintain a List of Mutex's/buffers Held by a Task
	struct ipc_buffer_object * prev;				// and memory allocation control for buffers
};


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_utilities.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_bytes.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_shorts.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_words.h"


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_words.h"


#include <stddef.h>

/* Return pointer to Highest Priority Task Ctrl Block */
struct task_ctrl_obj * internal_buffer_scheduler(struct ipc_buffer_object * resource){

	api_system_gateway();

	unsigned char internal_highest_priority;
	struct queue_ctrl_object * highest_qcb_act;
	struct task_ctrl_obj * highest_tcb_act;

	internal_highest_priority = internal_resource_retrieve_priority(&resource->priority_map[0]);

	highest_qcb_act = &resource->priority_levels[internal_highest_priority];
	highest_tcb_act = (struct task_ctrl_obj *)highest_qcb_act->tcb_next_exe;

	return(highest_tcb_act);
}

/* Insert task Ctrl Block of Resource Priority Pending List */
unsigned char internal_buffer_insert_task(struct ipc_buffer_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	tcb->resource_waiting = (void *)resource;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	tcb->task_status = BUFFER_WAITING;

	if( Queue->nr_tcb == Zero){
		Queue->tcb_next_exe	= tcb;
		tcb->tcb_next		= tcb;
		tcb->tcb_prev		= tcb;
		Queue->nr_tcb		= 1;
		// Mark Priority Map
		internal_resource_configure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else{
		Queue->nr_tcb++;
		tcb->tcb_next = (struct task_ctrl_obj *)Queue->tcb_next_exe;
		tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
		Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
		Queue->tcb_next_exe->tcb_prev = tcb;
	}

	#ifdef DARKNESSDEBUG
	DebugX.NrTasksDelayedBuffers++;
	#endif

	return(SUCCESSFUL);
}

/* Remove Task ctrl Block from Resourse Pending List */
unsigned char internal_buffer_remove_task(struct ipc_buffer_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();

	if(tcb->task_status != BUFFER_WAITING){ return ERROR; }

	tcb->task_status		= DORMANT;
	tcb->internal_ctrl		= DORMANT;
	tcb->resource_waiting	= NULL;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	if( Queue->nr_tcb == 1){
		Queue->nr_tcb = 0;           // Unmark Priority Map
		internal_resource_unconfigure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else
	{
		Queue->nr_tcb--;
		if(Queue->tcb_next_exe == tcb){
			Queue->tcb_next_exe = tcb->tcb_next;
		}
		tcb->tcb_prev->tcb_next = tcb->tcb_next;
		tcb->tcb_next->tcb_prev = tcb->tcb_prev;
	}

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedBuffers--;
	#endif

	return(SUCCESSFUL);
}



