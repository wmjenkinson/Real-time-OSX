/*
 * buffer_words.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_BUFFERS_BUFFER_SHORTS_H_
#define DARKNESS_DX_DARKNESS_API_BUFFERS_BUFFER_SHORTS_H_

extern struct ipc_buffer_object * api_create_buffer( unsigned short int);						// Create buffer
extern unsigned char api_delete_buffer(struct ipc_buffer_object * );				// Delete buffer
extern unsigned char api_post_to_buffer(struct ipc_buffer_object * ,  unsigned int);		// Post Data to buffer
extern unsigned char api_post_to_front(struct ipc_buffer_object * ,  unsigned int);		// Post to Front of buffer
extern unsigned char api_broadcast_to_buffer(struct ipc_buffer_object * ,  unsigned int);// Broadcast to All Task waiting on buffer
extern unsigned int api_pend_on_buffer(struct ipc_buffer_object * ,  unsigned short int,  unsigned char *);		// Accept Data Else Wait and or Delay
extern unsigned int api_buffer_accept(struct ipc_buffer_object * ,  unsigned char *);				// Accept Data if Available
extern unsigned char api_buffer_flush(struct ipc_buffer_object * );				// Flush Data


struct buffer16 {									// buffer Management
	unsigned short * buffer_start;				// Points to the Start of the buffer
	unsigned short * buffer_out;				// Points to the Data that is next to be removed
	unsigned short * buffer_in;					// Points to the Next Segment that Data is to be added
	unsigned short * buffer_end;				// Points to End of buffer
};




#endif /* DARKNESS_DX_DARKNESS_API_BUFFERS_BUFFER_SHORTS_H_ */
