#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"

#include <stddef.h>


struct token_ctrl_bit {
	struct token_ctrl_bit * next_token;
	struct token_ctrl_bit * prev_token;
	char datum;
};

struct token_ctrl_8bit {
	struct token_ctrl_8bit * next_token;
	struct token_ctrl_8bit * prev_token;
	unsigned char datum;
};

struct token_ctrl_16bit {
	struct token_ctrl_16bit * next_token;
	struct token_ctrl_16bit * prev_token;
	unsigned short int datum;
};

struct token_ctrl_32bit {
	struct token_ctrl_32bit * next_token;
	struct token_ctrl_32bit * prev_token;
	unsigned int datum;
};

struct token_ctrl_64bit {
	struct token_ctrl_64bit * next_token;
	struct token_ctrl_64bit * prev_token;
	unsigned long long int datum;
};

struct ipc_pipe_object {							// Resource Ctrl is used by, Nodes, buffer, Semaphores, Futexs, Mutex's
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;						// Semaphore Counter

	struct token_ctrl_32bit * free_token;
	unsigned int nr_tokens;

	struct token_ctrl_bit   * data_flow_1bit;		// Node Tokens
	struct token_ctrl_8bit  * data_flow_8bit;		// Node Tokens
	struct token_ctrl_16bit * data_flow_16bit;		// Node Tokens
	struct token_ctrl_32bit * data_flow_32bit;		// Node Tokens
	struct token_ctrl_64bit * data_flow_64bit;		// Node Tokens
};

/*
 *	Insert Task onto the Pipeline Waiting List
 */
unsigned char internal_pipe_insert_task(struct ipc_pipe_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

/*
 *	Remove Task from the PipeLine waiting List
 */
unsigned char internal_pipe_remove_task(struct ipc_pipe_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

/*
 *	Retrieve Highests, and FIFO Task from the Pipeline
 */
struct task_ctrl_obj * internal_pipe_scheduler(struct ipc_pipe_object *);						// Return TCB to highest task on resource

/* Nodes are small messages passed within an Application api_program Interface, of important note is that
   they will overwrite any previous data on the node. */
struct ipc_pipe_object *		api_create_pipe(void);												// Create Node
unsigned char					api_delete_pipe(struct ipc_pipe_object *);							// Delete Node
unsigned char					api_send_to_pipe(struct ipc_pipe_object *, unsigned int);			// Produce a token on a Node
unsigned char					api_broadcast_on_pipe(struct ipc_pipe_object *, unsigned int);		// BroadcaSt a token to all tasks waiting on a node
unsigned int					api_recieve_pipe(struct ipc_pipe_object *, unsigned short int);		// Consume a token on a Node
unsigned int					api_accept_pipe(struct ipc_pipe_object *);							// Accept a Token if available


/*
 *	Set aside Memory for the Pipeline/Tokens
 */
unsigned char configure_token_controller(struct ipc_pipe_object * pipe, int nr_tokens);

/*
 *	Return Token to the Pipeline freeing it for further use
 */
void return_token(struct ipc_pipe_object * pipe, struct token_ctrl_32bit * token);

/*
 *	Obtain Token from the Pipeline
 */
struct token_ctrl_32bit * allocate_token(struct ipc_pipe_object * pipe);

/*
 *	INTERNAL SYSTEM - For Placing Data into the Pipe
 */
void pump_data(struct ipc_pipe_object *, unsigned int);

/*
 *	INTERNAL PERATION - For Obtaing Data from Pipe
 */
unsigned int retrieve_data(struct ipc_pipe_object *);


struct ipc_pipe_object * api_create_pipe(void){	// Create Node

	api_system_gateway();
	struct ipc_pipe_object * node;

	node = malloc(sizeof(struct ipc_pipe_object));	// allocate memory for Node
	if(node == NULL){
		//print_dbg("Error Allocating Memory for a Node\n\r");
		return(NULL);
	}

	node->ipc_resource = 0; // Counter of Tokens equals Zero

	// Clear Priority Cube
	for(unsigned char i = 0; i < 9; i++){
			node->priority_map[i] = 0; }

	// Return Handler to the Pipe
	return(node);														// return handle to Node
}


unsigned char api_delete_pipe(struct ipc_pipe_object * node){

	api_system_gateway();

	struct task_ctrl_obj * tcb;

	while(node->ipc_resource != Zero){
		retrieve_data(node);
	}

	while(node->priority_map != EMPTY){		// if tasks WAITING on Node then free them
			tcb = internal_pipe_scheduler(node);		// obtain Task waiting on Node
			if(tcb->delay_counter!=Zero){	// if task also Delayed on a Timeout then
				internal_remove_delay(tcb);
			}
											// remove from delay queue
			internal_pipe_remove_task(node, tcb);	// remove task from waiting on Node
			tcb->task_status = EXCEPTION;	// Task status equals Exception
			internal_kernel_insert_task(tcb);		// Insert Task unto Kernel Scheduler
		}
	free(node);							// free Node Memory
	return(SUCCESSFUL);						// Return SUCCESSFUL
}


unsigned char api_send_to_pipe(struct ipc_pipe_object * node, unsigned int token){

	api_system_gateway();

	struct task_ctrl_obj *tcb;

	if(node->priority_map != EMPTY){		// Task(s) waiting on a taken then ready highest task

		tcb = internal_pipe_scheduler(node);			// Obtain highest priority task waiting on a Taken
		tcb->datum_return_32bit = token;	// pass token to task

		if(tcb->delay_counter != Zero){		// If task was delayed then remove from delay queue
			internal_remove_delay(tcb);
		}

		internal_pipe_remove_task(node, tcb);		// remove task from Node Priority Queue
		internal_kernel_insert_task(tcb);			// Insert Task unto Kernel Scheduler

		// If Context switch required then preform a swtich
		if(internal_highest_priority() < core_executing_task->delta_priority){
			internal_executive_dispatcher();

			// There is another mechanism which can be used to achieve something similar: memory barriers.
			// This is accomplished through adding a special "memory" clobber to the assembler statement,
			// and ensures that all variables are flushed from registers to memory before the statement,
			// and then re-read after the statement.
			asm volatile("" ::: "memory");
		}
	}
	else{
		pump_data(node, token);
	}
	return(SUCCESSFUL);
}


unsigned char api_broadcast_on_pipe(struct ipc_pipe_object * node, unsigned int token){

	api_system_gateway();

	struct task_ctrl_obj *tcb;

	if(node->priority_map != EMPTY){			// if Task(s) waiting on priority queue then ready
		while(node->priority_map != EMPTY){		// all tasks and pass the token to each task
			tcb = internal_pipe_scheduler(node);

			if(tcb->delay_counter != Zero){		// if task(s) delayed then remove each task delayed
				internal_remove_delay(tcb);				// from the delay queue
			}

			internal_pipe_remove_task(node, tcb);		// remove task(s) from the Node priority queue
			internal_kernel_insert_task(tcb);			// insert task(s) unto the kernel Scheduler
			tcb->datum_return_32bit = token;	// pass token to each task
		}
		if(internal_highest_priority() < core_executing_task->delta_priority){
			internal_executive_dispatcher();

			// There is another mechanism which can be used to achieve something similar: memory barriers.
			// This is accomplished through adding a special "memory" clobber to the assembler statement,
			// and ensures that all variables are flushed from registers to memory before the statement,
			// and then re-read after the statement.
			asm volatile("" ::: "memory");
		}
	}
	else{
		pump_data(node, token);
	}
	return(SUCCESSFUL);
}


unsigned int api_recieve_pipe(struct ipc_pipe_object * node, unsigned short int delay){

	api_system_gateway();

	struct task_ctrl_obj * tcb;
	unsigned int datum;

	tcb  = (struct task_ctrl_obj *)core_executing_task;

	if(node->ipc_resource == clear){	// if no tokens available then pend on Node

		internal_kernel_remove_task(tcb);		// remove task from Kernel Scheduler
		internal_pipe_insert_task(node, tcb);	// insert task unto Node priority wait list

		if(delay != 0){					// if timeout specified then also place the
			api_delay_task(tcb, delay);		// task on the delay queue
		}

		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		asm volatile("" ::: "memory");


		if(core_executing_task->internal_ctrl == TIMEOUT){
			core_executing_task->internal_ctrl = acknowledge;
			return((unsigned int)TIMEOUT);
		}
		else{
			return(core_executing_task->datum_return_32bit);
		}
	}
	else{
		datum = retrieve_data(node);
		return(datum);
	}
}


unsigned int api_accept_pipe(struct ipc_pipe_object * node){

	api_system_gateway();

	unsigned int datum;

	if(node->ipc_resource == 0){
		return(EMPTY);
	}
	else{
		datum = retrieve_data(node);
		return(datum);
	}
}


unsigned int retrieve_data(struct ipc_pipe_object * node){

	api_system_gateway();

	unsigned int datum;

	struct token_ctrl_32bit * token_ret = (struct token_ctrl_32bit *)node->data_flow_32bit;

	if( node->ipc_resource == 1){
		node->ipc_resource = 0;
		datum = node->data_flow_32bit->datum;
		}
	else
	{
		node->ipc_resource--;
		node->data_flow_32bit = token_ret->next_token;

		datum = token_ret->datum;

		token_ret->prev_token->next_token = token_ret->next_token;
		token_ret->next_token->prev_token = token_ret->prev_token;
	}

	return_token(node, token_ret);
	return(datum);
}


void pump_data(struct ipc_pipe_object * node, unsigned int datum){

	api_system_gateway();

	struct token_ctrl_32bit * token_Sav = allocate_token(node);

	token_Sav->datum = datum;

	if( node->ipc_resource == Zero){
		node->data_flow_32bit		= token_Sav;
		token_Sav->next_token		= token_Sav;
		token_Sav->prev_token		= token_Sav;
		node->ipc_resource			= 1;
		}
	else{
		node->ipc_resource++;
		token_Sav->next_token = node->data_flow_32bit;
		token_Sav->prev_token = node->data_flow_32bit->prev_token;
		node->data_flow_32bit->prev_token->next_token = token_Sav;
		node->data_flow_32bit->prev_token = token_Sav;
	}
}

/* Return pointer to Highest Priority Task Ctrl Block */
struct task_ctrl_obj * internal_pipe_scheduler(struct ipc_pipe_object * resource){

	api_system_gateway();

	unsigned char internal_highest_priority;
	struct queue_ctrl_object * highest_qcb_act;
	struct task_ctrl_obj * highest_tcb_act;

	internal_highest_priority = internal_resource_retrieve_priority(&resource->priority_map[0]);

	highest_qcb_act = &resource->priority_levels[internal_highest_priority];
	highest_tcb_act = (struct task_ctrl_obj *)highest_qcb_act->tcb_next_exe;

	return(highest_tcb_act);
}

/* Insert task Ctrl Block of Resource Priority Pending List */
unsigned char internal_pipe_insert_task(struct ipc_pipe_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	tcb->resource_waiting = (void *)resource;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedPipes++;
	#endif

	tcb->task_status = PIPE_WAITING;

	if( Queue->nr_tcb == Zero){
		Queue->tcb_next_exe	= tcb;
		tcb->tcb_next		= tcb;
		tcb->tcb_prev		= tcb;
		Queue->nr_tcb		= 1;
		// Mark Priority Map
		internal_resource_configure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else{
		Queue->nr_tcb++;
		tcb->tcb_next = (struct task_ctrl_obj *)Queue->tcb_next_exe;
		tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
		Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
		Queue->tcb_next_exe->tcb_prev = tcb;
	}
	return(SUCCESSFUL);
}

/* Remove Task ctrl Block from Resourse Pending List */
unsigned char internal_pipe_remove_task(struct ipc_pipe_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedPipes--;
	#endif

	if(tcb->task_status != WAITING_ON_EVENT){ return ERROR; }

	tcb->task_status		= DORMANT;
	tcb->internal_ctrl		= DORMANT;
	tcb->resource_waiting	= NULL;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	if( Queue->nr_tcb == 1){
		Queue->nr_tcb = 0;           // Unmark Priority Map
		internal_resource_unconfigure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else
	{
		Queue->nr_tcb--;
		if(Queue->tcb_next_exe == tcb){
			Queue->tcb_next_exe = tcb->tcb_next;
		}
		tcb->tcb_prev->tcb_next = tcb->tcb_next;
		tcb->tcb_next->tcb_prev = tcb->tcb_prev;
	}
	return(SUCCESSFUL);
}



unsigned char configure_token_controller(struct ipc_pipe_object * pipe, int nr_tokens){ api_system_gateway();


	struct token_ctrl_32bit * token;

	for(int i = 0; i < nr_tokens; i++){

		token = malloc(sizeof(struct token_ctrl_32bit));
		return_token(pipe, token);
	}
	return (true);
}


void return_token(struct ipc_pipe_object * pipe, struct token_ctrl_32bit * token){ api_system_gateway();


	if( pipe->nr_tokens == 0){
		pipe->free_token								= token;
		token->next_token								= token;
		token->prev_token								= token;
		pipe->nr_tokens									= 1;
	}
	else{
		pipe->free_token++;
		token->next_token = pipe->free_token;
		token->prev_token = pipe->free_token->prev_token;
		pipe->free_token->prev_token->next_token = token;
		pipe->free_token->prev_token = token;

	}
}


struct token_ctrl_32bit * allocate_token(struct ipc_pipe_object * pipe){ api_system_gateway();

	struct token_ctrl_32bit * token;



	token = pipe->free_token;

	if( pipe->nr_tokens == 1){
		pipe->nr_tokens = 0;           // Unmark Priority Map
	}
	else
	{
		pipe->nr_tokens--;

		pipe->free_token = token->next_token;

		token->prev_token->next_token = token->next_token;
		token->next_token->prev_token = token->prev_token;
	}
	return(token);
}

