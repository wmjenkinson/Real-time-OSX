/*
 * mailbox_library.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_MAILBOX_LIBRARY_H_
#define DARKNESS_DX_DARKNESS_API_MAILBOX_LIBRARY_H_



#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"


struct parcel_obj {									// Envelope
	struct task_ctrl_obj * sender;					// Sender address, from tcb ID
	struct task_ctrl_obj * reciever;				// Receiver address, target ID
	unsigned char  priority;						// Parcel Priority
	void *  message;								// Envelope Message
	struct parcel_obj * next_parcel;				// Pointer to the next message, double link list to allow transferssing
	struct parcel_obj * prev_parcel;				// removal and insertion of envelopes
};

struct mailbox_obj{									// mailbox manager for each priority level
	struct parcel_obj * start;
	unsigned short int nr_parcels;
};


struct ipc_mailbox_object {							// Resource Ctrl is used by, Mailboxs
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING

	struct task_ctrl_obj * holder;					// Points To Resource Holder

	struct mailbox_obj priorities_mail[64];
	unsigned char  MailBoxPriMap[9];


	unsigned int nr_free;
	struct parcel_obj * free_parcel;
};

/* Nodes are small messages passed within an Application api_program Interface, of important note is that
   they will overwrite any previous data on the node. */


extern unsigned char internal_mailbox_insert_task(struct ipc_mailbox_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

extern unsigned char internal_mailbox_remove_task(struct ipc_mailbox_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

extern struct task_ctrl_obj * internal_mailbox_scheduler(struct ipc_mailbox_object *);				// Return TCB to highest task on resource


extern struct ipc_mailbox_object *		api_create_mailbox(void);

extern unsigned char					api_post_to_mailbox(struct ipc_mailbox_object *, struct task_ctrl_obj *, void *);

extern void *					api_recieve_mail(struct ipc_mailbox_object *, struct task_ctrl_obj *, unsigned short int);

extern void *					api_accept_mail(struct ipc_mailbox_object *, struct task_ctrl_obj *);

extern void                    internal_schedule_tcb(struct ipc_mailbox_object *, struct task_ctrl_obj *);

extern void					internal_disgard_parcel(struct ipc_mailbox_object *, struct parcel_obj *);

extern unsigned char internal_configure_parcels(struct ipc_mailbox_object * mailbox, int nr_system_packets);

extern struct parcel_obj * internal_allocate_parcel(struct ipc_mailbox_object * mailbox);

extern void internal_return_parcel(struct ipc_mailbox_object * mailbox, struct parcel_obj * parcel);




#endif /* DARKNESS_DX_DARKNESS_API_MAILBOX_LIBRARY_H_ */
