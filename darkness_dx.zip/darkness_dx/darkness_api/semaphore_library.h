/*
 * semaphore_library.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_SEMAPHORE_LIBRARY_H_
#define DARKNESS_DX_DARKNESS_API_SEMAPHORE_LIBRARY_H_


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

struct ipc_semaphore_object {						// Resource Ctrl is used by, Semaphores
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;						// Semaphore Counter
	unsigned int semaphore_apache;
};

struct ipc_semaphore_object * memory_controller;




/*
 *	Insert Task unto the Semaphores waiting list
 */
extern unsigned char internal_semaphore_insert_task(struct ipc_semaphore_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

/*
 *	Remove Task from the Semaphores waiting List
 */
extern unsigned char internal_semaphore_remove_task(struct ipc_semaphore_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

/*
 *	Schedule Highest and FIFO Task on the Semaphores witing List
 */
extern struct task_ctrl_obj * internal_semaphore_scheduler(struct ipc_semaphore_object *);				// Return TCB to highest task on resource


extern struct ipc_semaphore_object * api_create_semaphore(unsigned int, unsigned int);			// Create Semaphore
extern unsigned char  api_delete_semaphore(struct ipc_semaphore_object *);						// Delete Semaphore
extern unsigned char  api_pend_semaphore(struct ipc_semaphore_object *, unsigned int);			// Pend on Semaphore, with optional delay
extern unsigned char  api_post_semaphore(struct ipc_semaphore_object *);						// Post on Semhpore
extern unsigned char  api_accept_semaphore(struct ipc_semaphore_object *);

extern unsigned char  api_take_semaphore(struct ipc_semaphore_object *, unsigned int);			// Pend on Semaphore, with optional delay
extern unsigned char  api_give_semaphore(struct ipc_semaphore_object *);						// Post on Semhpore




#endif /* DARKNESS_DX_DARKNESS_API_SEMAPHORE_LIBRARY_H_ */
