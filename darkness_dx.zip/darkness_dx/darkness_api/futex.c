#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"

#include <stddef.h>


struct ipc_futex_object {							// Resource Ctrl is used by, Futex's
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;						// Semaphore Counter
	unsigned int futex_recursion;

	struct task_ctrl_obj * holder;					// Points To Resource Holder
};

unsigned char internal_futex_insert_task(struct ipc_futex_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list
unsigned char internal_futex_remove_task(struct ipc_futex_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list
struct task_ctrl_obj * internal_futex_scheduler(struct ipc_futex_object *);				// Return TCB to highest task on resource

struct ipc_futex_object * api_create_futex(void);					// Creat Futex
unsigned char api_delete_futex(struct ipc_futex_object *);					// Delete Futex
unsigned char api_pend_futex(struct ipc_futex_object *, unsigned short int);			// Pend On Futex
unsigned char api_post_futex(struct ipc_futex_object *);					// Post On Futex
unsigned char api_accept_futex(struct ipc_futex_object *);			// Accept Futex



struct ipc_futex_object * api_create_futex(void){

	api_system_gateway();
	struct ipc_futex_object * futex;

	futex = malloc(sizeof(struct ipc_futex_object));			// Allocate Memory to Futex Structure
	if(futex == NULL){
		//print_dbg("Error Allocating Memory for Futex\n\r");
		return(NULL);
	}

	futex->ipc_resource = available;							// Set Initial Lock Value

	for(unsigned char i = 0; i < 9; i++){
	futex->priority_map[i] = clear; }

	futex->holder		= (struct task_ctrl_obj *)NULL;

	return(futex);											// Return Futex Pointer
}

/*Delete Futex */
unsigned char api_delete_futex(struct ipc_futex_object * futex){

	api_system_gateway();

	struct task_ctrl_obj * tcb;

	while(futex->priority_map[_group] != EMPTY){					// If Tasks are WAITING on the Futex then
		tcb = internal_futex_scheduler(futex);							// READY each task.

		if(tcb->delay_counter != 0){							// If task is also delayed then remove from delay queue
			internal_remove_delay(tcb);
		}

		internal_futex_remove_task(futex, tcb);							// Remove task from Resource
		tcb->task_status = EXCEPTION;						// Signal an exception
		internal_kernel_insert_task(tcb);							// and insert Task unto Kernel Scheduler
	}
	free(futex);											// free FUTEX

	return(SUCCESSFUL);										// Return SUCCESSFUL
}

/* Pend on FUTEX */
unsigned char api_pend_futex(struct ipc_futex_object * futex, unsigned short int delay){
	api_system_gateway();

	struct task_ctrl_obj * tcb = (struct task_ctrl_obj *)core_executing_task;

	if(futex->holder == tcb){
		futex->futex_recursion++;
		tcb->total_futexs_held++;
		return(FUTEX_ACK);
	}

	if(futex->ipc_resource == available){							// If True then FUTEX is available
		futex->ipc_resource = unavailable;
		futex->futex_recursion = 1;
		futex->holder = tcb;
		tcb->total_futexs_held++;

		// Set Delta Priority to cieling if required, this assumption is equally true if the task
		// has had its priority incremented by a Mutex
		if(tcb->delta_priority > tcb->ceiling_priority){
			internal_kernel_remove_task(tcb);
			tcb->delta_priority = tcb->ceiling_priority;
			internal_kernel_insert_task(tcb);
		}
		return(FUTEX_ACK);									// and return ACK
	}
	else{													// Else delay Task on FUTEX

		//	if(kernel_core.interrupt_service_routine != 0){
		//		return(ACCESS_DENIED);
		//	}

		internal_kernel_remove_task(tcb);				// Remove Task from Scheduler
		internal_futex_insert_task(futex, tcb);				// Insert onto FUTEX Resource Scheduler

		if(delay != 0){
			api_delay_task(tcb, delay);				// If DELAY Specified then also place task unto
		}
		// Delay Queue
		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		asm volatile ( "" ::: "memory");							// has been delayed
	}

	if(core_executing_task->internal_ctrl == TIMEOUT){
		core_executing_task->internal_ctrl = acknowledge;
		return(TIMEOUT);
	}
	else{
		return(FUTEX_ACK);					// HOOK, return task status
	}
}

// Post to FUTEX/LOCK
unsigned char api_post_futex(struct ipc_futex_object * futex){

	api_system_gateway();

	if(futex->holder != core_executing_task){
		return(ERROR);
	}

	struct task_ctrl_obj * tcb = (struct task_ctrl_obj *)core_executing_task;

	futex->futex_recursion--;
	tcb->total_futexs_held--;

	if(futex->futex_recursion == Zero){

		futex->ipc_resource = available;								// Else reliquish LOCK
		futex->holder = (struct task_ctrl_obj *)NULL;

		if(tcb->delta_priority != tcb->default_priority){
			if(tcb->total_futexs_held == 0){

				internal_kernel_remove_task(tcb);
				#ifdef Mutex_Enable
				if(tcb->default_priority < internal_resource_retrieve_priority(&tcb->Mutex_Map[0])){
					tcb->delta_priority = tcb->default_priority;
				}
				else{
					tcb->delta_priority = internal_resource_retrieve_priority(&tcb->Mutex_Map[0]);
				}
				#else
				tcb->delta_priority = tcb->default_priority;
				#endif
				internal_kernel_insert_task(tcb);
			}
		}

		if(futex->priority_map[_group] != EMPTY){						// if task waiting on FUTEX then ready the
			tcb = internal_futex_scheduler(futex);							// highest task
			internal_futex_remove_task(futex, tcb);							// remove highest task from resource queue

			if(tcb->delay_counter != Zero){
				internal_remove_delay(tcb);
			}

			tcb->internal_ctrl = FUTEX_ACK;

			futex->ipc_resource = unavailable;
			futex->futex_recursion = 1;
			futex->holder = tcb;
			tcb->total_futexs_held++;

			// Increase Task Delta Priority to its Ceiling Priority
			if(tcb->delta_priority > tcb->ceiling_priority){
				tcb->delta_priority = tcb->ceiling_priority;
			}
			internal_kernel_insert_task(tcb);


			if((tcb->delta_priority < core_executing_task->delta_priority) && (core_executing_task->dsr_active == false)){	// Preform Contex switch if readyed task is
				internal_executive_dispatcher();

				// There is another mechanism which can be used to achieve something similar: memory barriers.
				// This is accomplished through adding a special "memory" clobber to the assembler statement,
				// and ensures that all variables are flushed from registers to memory before the statement,
				// and then re-read after the statement.
				asm volatile ( "" ::: "memory");
			}
		}
	}
	return(SUCCESSFUL);
}

/* ACCEPT FUTEX, do not wait for resource if it is unavailable */
unsigned char api_accept_futex(struct ipc_futex_object * futex){

	api_system_gateway();

	struct task_ctrl_obj * tcb = (struct task_ctrl_obj *)core_executing_task;

	if(futex->holder == tcb){
		futex->futex_recursion++;
		tcb->total_futexs_held++;
		return(FUTEX_ACK);
	}

	if(futex->ipc_resource == available){

		futex->ipc_resource = unavailable;
		futex->futex_recursion = 1;
		futex->holder = (struct task_ctrl_obj *)tcb;
		tcb->total_futexs_held++;

		// Increase Task Delta Priority to its Ceiling Priority
		if(tcb->delta_priority > tcb->ceiling_priority){
			internal_kernel_remove_task(tcb);
			tcb->delta_priority = tcb->ceiling_priority;
			internal_kernel_insert_task(tcb);
		}
		return(FUTEX_ACK);
	}
	else{
		return(FAILURE);
	}
}

// Wait List
/* Return pointer to Highest Priority Task Ctrl Block */
struct task_ctrl_obj * internal_futex_scheduler(struct ipc_futex_object * resource){

	api_system_gateway();

	unsigned char internal_highest_priority;
	struct queue_ctrl_object * highest_qcb_act;
	struct task_ctrl_obj * highest_tcb_act;

	internal_highest_priority = internal_resource_retrieve_priority(&resource->priority_map[0]);

	highest_qcb_act = &resource->priority_levels[internal_highest_priority];
	highest_tcb_act = (struct task_ctrl_obj *)highest_qcb_act->tcb_next_exe;

	return(highest_tcb_act);
}

/* Insert task Ctrl Block of Resource Priority Pending List */
unsigned char internal_futex_insert_task(struct ipc_futex_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	tcb->resource_waiting = (void *)resource;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedFutexs++;
	#endif

	tcb->task_status = FUTEX_WAITING;

	if( Queue->nr_tcb == Zero){
		Queue->tcb_next_exe	= tcb;
		tcb->tcb_next		= tcb;
		tcb->tcb_prev		= tcb;
		Queue->nr_tcb		= 1;
		// Mark Priority Map
		internal_resource_configure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else{
		Queue->nr_tcb++;
		tcb->tcb_next = (struct task_ctrl_obj *)Queue->tcb_next_exe;
		tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
		Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
		Queue->tcb_next_exe->tcb_prev = tcb;
	}
	return(SUCCESSFUL);
}

/* Remove Task ctrl Block from Resourse Pending List */
unsigned char internal_futex_remove_task(struct ipc_futex_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedFutexs--;
	#endif

	if(tcb->task_status != FUTEX_WAITING){ return ERROR; }

	tcb->task_status		= DORMANT;
	tcb->internal_ctrl		= DORMANT;
	tcb->resource_waiting	= NULL;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	if( Queue->nr_tcb == 1){
		Queue->nr_tcb = 0;           // Unmark Priority Map
		internal_resource_unconfigure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else
	{
		Queue->nr_tcb--;
		if(Queue->tcb_next_exe == tcb){
			Queue->tcb_next_exe = tcb->tcb_next;
		}
		tcb->tcb_prev->tcb_next = tcb->tcb_next;
		tcb->tcb_next->tcb_prev = tcb->tcb_prev;
	}
	return(SUCCESSFUL);
}
