#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\watchdog.h"

extern void * api_malloc(unsigned int);


struct watchdog_application * api_createwatchdog(int var){

	struct watchdog_application * created_watchdog = api_malloc(sizeof(struct watchdog_application));

	if(created_watchdog->watchdog_time == 0){
		created_watchdog->watchdog_time = var;
		created_watchdog->system_notice = kernel_core.kernel_stamp;
	}
	return created_watchdog;
}

void api_ping_watchdog(struct watchdog_application * target_watchdog){
	target_watchdog->system_notice = kernel_core.kernel_stamp;
}

char api_pong_watchdog(struct watchdog_application * target_watchdog){
	if((target_watchdog->watchdog_time + target_watchdog->system_notice) > kernel_core.kernel_stamp){
		return true;
	}
	else{
		return false;
	}
}

