#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"

#include <stddef.h>

struct parcel_obj {									// Envelope
	struct task_ctrl_obj * sender;					// Sender address, from tcb ID
	struct task_ctrl_obj * reciever;				// Receiver address, target ID
	unsigned char  priority;						// Parcel Priority
	void *  message;								// Envelope Message
	struct parcel_obj * next_parcel;				// Pointer to the next message, double link list to allow transferssing
	struct parcel_obj * prev_parcel;				// removal and insertion of envelopes
};

struct mailbox_obj{									// mailbox manager for each priority level
	struct parcel_obj * start;
	unsigned short int nr_parcels;
};


struct ipc_mailbox_object {							// Resource Ctrl is used by, Mailboxs
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING

	struct task_ctrl_obj * holder;					// Points To Resource Holder

	struct mailbox_obj priorities_mail[64];
	unsigned char  MailBoxPriMap[9];


	unsigned int nr_free;
	struct parcel_obj * free_parcel;
};


unsigned char internal_mailbox_insert_task(struct ipc_mailbox_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list
unsigned char internal_mailbox_remove_task(struct ipc_mailbox_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list
struct task_ctrl_obj * internal_mailbox_scheduler(struct ipc_mailbox_object *);				// Return TCB to highest task on resource


struct ipc_mailbox_object * api_create_mailbox(void);

unsigned char api_post_to_mailbox(struct ipc_mailbox_object *, struct task_ctrl_obj *, void *);
void * api_recieve_mail(struct ipc_mailbox_object *, struct task_ctrl_obj *, unsigned short int);
void * api_accept_mail(struct ipc_mailbox_object *, struct task_ctrl_obj *);

void internal_schedule_tcb(struct ipc_mailbox_object *, struct task_ctrl_obj *);
void internal_disgard_parcel(struct ipc_mailbox_object *, struct parcel_obj *);

unsigned char internal_configure_parcels(struct ipc_mailbox_object * mailbox, int nr_system_packets);
struct parcel_obj * internal_allocate_parcel(struct ipc_mailbox_object * mailbox);
void internal_return_parcel(struct ipc_mailbox_object * mailbox, struct parcel_obj * parcel);

struct ipc_mailbox_object * api_create_mailbox(void){

	api_system_gateway();
	struct ipc_mailbox_object * mailbox;

	mailbox = malloc(sizeof(struct ipc_mailbox_object));
	if(mailbox == NULL){
		//print_dbg("Error Allocating Memory for Futex\n\r");
		return(NULL);
	}

	for(unsigned char i = 0; i < 9; i++){
	mailbox->priority_map[i]  = 0;	mailbox->MailBoxPriMap[i] = 0; }

	internal_configure_parcels(mailbox, 50);

	return(mailbox);
}

unsigned char api_post_to_mailbox(struct ipc_mailbox_object * mailbox, struct task_ctrl_obj * to, void * token){

	api_system_gateway();

	struct task_ctrl_obj * tcb;

	if(mailbox->priority_map[_group] != EMPTY){

		// Obtain the highest Priority Task waiting and begin processing from there through the Priority Group
		unsigned char sorting = internal_resource_retrieve_priority(&mailbox->priority_map[0]);
		for(unsigned char i = sorting; i < 64; i++){

			// Obtain the number of tasks at the particular group
			unsigned char nr_tasks_waiting = mailbox->priority_levels[i].nr_tcb;
			for(unsigned char j = 0;j < nr_tasks_waiting;j++){

				// Daisey Chain through the Double Link List
				tcb = (struct task_ctrl_obj *)mailbox->priority_levels[i].tcb_next_exe;
				mailbox->priority_levels[i].tcb_next_exe = mailbox->priority_levels[i].tcb_next_exe->tcb_next;

				// AND LOOK FOR A MATCHING DELIVARY
				if((tcb->from == api_ownID()) && (tcb == to)){
					tcb->internal_ctrl = SUCCESSFUL;
					tcb->datum_return = (void *)token;
					internal_schedule_tcb(mailbox, tcb);
					return(SUCCESSFUL);
				}
				else if((tcb->from == from_anyone) && (tcb == to)){
					tcb->internal_ctrl = SUCCESSFUL;
					tcb->datum_return = (void *)token;
					internal_schedule_tcb(mailbox, tcb);
					return(SUCCESSFUL);
				}
				else if((tcb->from == api_ownID()) && (to == to_anyone)){
					tcb->internal_ctrl = SUCCESSFUL;
					tcb->datum_return = (void *)token;
					internal_schedule_tcb(mailbox, tcb);
					return(SUCCESSFUL);
				}
				else if((tcb->from == from_anyone) && (to == to_anyone)){
					tcb->internal_ctrl = SUCCESSFUL;
					tcb->datum_return = (void *)token;
					internal_schedule_tcb(mailbox, tcb);
					return(SUCCESSFUL);
				}
			}
		}
	}


	struct parcel_obj * parcel = internal_allocate_parcel(mailbox);

	parcel->message = token;
	parcel->reciever = to;

	if(core_executing_task->application_mode == true){ // TAG ERROR Wm. Jenkinson
		parcel->sender   = api_ownID();
		parcel->priority = api_ownID()->delta_priority;
	}
	else{
		parcel->sender   = api_ownID();
		parcel->priority = 0;
	}

	struct mailbox_obj * mailbox_slot = &mailbox->priorities_mail[parcel->priority];

	if( mailbox_slot->nr_parcels == 0){
		mailbox_slot->start		 = parcel;
		parcel->next_parcel		 = parcel;
		parcel->prev_parcel		 = parcel;
		mailbox_slot->nr_parcels = 1;
		// Mark Priority Level on the Kernel has being ACTIVE
		internal_resource_configure_priority(&mailbox->MailBoxPriMap[0], parcel->priority);
	}
	else{
		mailbox_slot->nr_parcels++;
		parcel->next_parcel = mailbox_slot->start;
		parcel->prev_parcel = mailbox_slot->start->prev_parcel;
		mailbox_slot->start->prev_parcel->next_parcel = parcel;
		mailbox_slot->start->prev_parcel = parcel;
	}
	return(SAVED);
}

void * api_recieve_mail(struct ipc_mailbox_object * mailbox, struct task_ctrl_obj * from, unsigned short int delay){

	api_system_gateway();

	struct parcel_obj  * parcel;
	struct mailbox_obj * postbox;

	void * letter;

	// Is There Mail in the System
	if(mailbox->MailBoxPriMap[_group] != EMPTY){

		// Priorities from the highest priority first
		unsigned char sorting = internal_resource_retrieve_priority(&mailbox->MailBoxPriMap[0]);

		for(unsigned char mail_priority = sorting; mail_priority < 64; mail_priority++){

			postbox = &mailbox->priorities_mail[mail_priority];
			unsigned char nr_mail = mailbox->priorities_mail[mail_priority].nr_parcels;

			for(unsigned char i = 0;i < nr_mail; i++){

				// Get Parcel and prepare for the next parcel
				parcel = (struct parcel_obj *)postbox->start;
				postbox->start = parcel->next_parcel;

				// LOOK FOR A MATCH
				if((from == parcel->sender) && (api_ownID() == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
				else if((from == from_anyone) && (api_ownID() == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
				else if((from == parcel->sender) && (to_anyone == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
				else if((from == from_anyone) && (to_anyone == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
			}
		}
	}

	struct task_ctrl_obj * tcb = (struct task_ctrl_obj *)core_executing_task;

	tcb->from = from;

	internal_kernel_remove_task(tcb);
	internal_mailbox_insert_task(mailbox, tcb);

	if(delay != Zero){
		api_delay_task(tcb, delay);
	}

	internal_executive_dispatcher();

	// There is another mechanism which can be used to achieve something similar: memory barriers.
	// This is accomplished through adding a special "memory" clobber to the assembler statement,
	// and ensures that all variables are flushed from registers to memory before the statement,
	// and then re-read after the statement.
	asm volatile ("" ::: "memory");

	if(tcb->internal_ctrl == TIMEOUT){
		tcb->internal_ctrl = acknowledge;
		return((void *)TIMEOUT);
	}
	else{
		tcb->internal_ctrl = acknowledge;
		return((void *)tcb->datum_return);
	}
}


void * api_accept_mail(struct ipc_mailbox_object * mailbox, struct task_ctrl_obj * from){

	api_system_gateway();

	struct parcel_obj  * parcel;
	struct mailbox_obj * postbox;

	void * letter;

	// if mail present in the mailbox then check for mail addressed to myself
	if(mailbox->MailBoxPriMap[_group] != EMPTY){

		// start at the highest priority saving some processing time
		unsigned char sorting = internal_resource_retrieve_priority(&mailbox->MailBoxPriMap[0]);

		/****************************************************************************************************/
		// Sort from the highest priority making our way down the list to lower levels it a match is not found
		for(unsigned char mail_priority = sorting; mail_priority < 64; mail_priority++){


			postbox = &mailbox->priorities_mail[mail_priority];
			unsigned char nr_mail = mailbox->priorities_mail[mail_priority].nr_parcels;

			for(unsigned char i = 0;i < nr_mail; i++){

				// Get Parcel and prepare to move to the next parcel
				parcel = (struct parcel_obj *)postbox->start;
				postbox->start = postbox->start->next_parcel;

				// LOOK FOR A MATCH
				if((from == parcel->sender) && (api_ownID() == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
				else if((from == from_anyone) && (api_ownID() == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
				else if((from == parcel->sender) && (to_anyone == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
				else if((from == from_anyone) && (to_anyone == parcel->reciever)){

					letter = (void *)parcel->message;
					internal_disgard_parcel(mailbox, parcel);
					return(letter);
				}
			}
		}
	}
	return(EMPTY);
}




void internal_disgard_parcel(struct ipc_mailbox_object * mailbox, struct parcel_obj * parcel){

	api_system_gateway();

	struct mailbox_obj * priority_queue = &mailbox->priorities_mail[parcel->priority];

	if( priority_queue->nr_parcels == 1){
		priority_queue->nr_parcels = 0;
		internal_resource_unconfigure_priority(&mailbox->MailBoxPriMap[0], parcel->priority);
	}
	else
	{
		priority_queue->nr_parcels--;
		if(priority_queue->start == parcel){
			priority_queue->start = parcel->next_parcel;
		}
		parcel->prev_parcel->next_parcel = parcel->next_parcel;
		parcel->next_parcel->prev_parcel = parcel->prev_parcel;
	}
	internal_return_parcel(mailbox, parcel);
}

/* re-schedule task onto kernel */
void internal_schedule_tcb(struct ipc_mailbox_object * mailbox,  struct task_ctrl_obj * tcb){

	api_system_gateway();

	internal_mailbox_remove_task(mailbox, tcb);

	if(tcb->delay_counter != 0){
		internal_remove_delay(tcb);
	}

	internal_kernel_insert_task(tcb);

	if(tcb->delta_priority < core_executing_task->delta_priority){	// Preform Contex switch if readyed task is
		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		asm volatile ("" ::: "memory");
	}
}


// Wait List
/* Return pointer to Highest Priority Task Ctrl Block */
struct task_ctrl_obj * internal_mailbox_scheduler(struct ipc_mailbox_object * resource){

	api_system_gateway();

	volatile unsigned char internal_highest_priority;
	volatile struct queue_ctrl_object * highest_qcb_act;
	volatile struct task_ctrl_obj * highest_tcb_act;

	internal_highest_priority = internal_resource_retrieve_priority(&resource->priority_map[0]);

	highest_qcb_act = &resource->priority_levels[internal_highest_priority];
	highest_tcb_act = (struct task_ctrl_obj *)highest_qcb_act->tcb_next_exe;

	return((struct task_ctrl_obj *)highest_tcb_act);
}

/* Insert task Ctrl Block of Resource Priority Pending List */
unsigned char internal_mailbox_insert_task(struct ipc_mailbox_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	tcb->resource_waiting = (void *)resource;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];
	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedMailBoxs++;
	#endif

	tcb->task_status = MAILBOX_WAITING;

	if( Queue->nr_tcb == Zero){
		Queue->tcb_next_exe	= tcb;
		tcb->tcb_next		= tcb;
		tcb->tcb_prev		= tcb;
		Queue->nr_tcb		= 1;
		// Mark Priority Map
		internal_resource_configure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else{
		Queue->nr_tcb++;
		tcb->tcb_next = (struct task_ctrl_obj *)Queue->tcb_next_exe;
		tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
		Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
		Queue->tcb_next_exe->tcb_prev = tcb;
	}
	return(SUCCESSFUL);
}

/* Remove Task ctrl Block from Resourse Pending List */
unsigned char internal_mailbox_remove_task(struct ipc_mailbox_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedMailBoxs--;
	#endif

	if(tcb->task_status != MAILBOX_WAITING){ return ERROR; }

	tcb->task_status		= DORMANT;
	tcb->internal_ctrl		= acknowledge;
	tcb->resource_waiting	= NULL;

	volatile struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	if( Queue->nr_tcb == 1){
		Queue->nr_tcb = 0;           // Unmark Priority Map
		internal_resource_unconfigure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else
	{
		Queue->nr_tcb--;
		if(Queue->tcb_next_exe == tcb){
			Queue->tcb_next_exe = tcb->tcb_next;
		}
		tcb->tcb_prev->tcb_next = tcb->tcb_next;
		tcb->tcb_next->tcb_prev = tcb->tcb_prev;
	}
	return(SUCCESSFUL);
}



unsigned char internal_configure_parcels(struct ipc_mailbox_object * mailbox, int nr_system_packets){ api_system_gateway();

	struct parcel_obj * parcel;

	for(int i = 0; i < nr_system_packets; i++){

		parcel = malloc(sizeof(struct parcel_obj));
		internal_return_parcel(mailbox, parcel);
	}
	return (true);
}



void internal_return_parcel(struct ipc_mailbox_object * mailbox, struct parcel_obj * parcel){ api_system_gateway();


	if( mailbox->nr_free == 0){
		mailbox->free_parcel							= parcel;
		parcel->next_parcel								= parcel;
		parcel->prev_parcel								= parcel;
		mailbox->nr_free								= 1;
	}
	else{
		mailbox->nr_free++;
		parcel->next_parcel = mailbox->free_parcel;
		parcel->prev_parcel = mailbox->free_parcel->prev_parcel;
		mailbox->free_parcel->prev_parcel->next_parcel = parcel;
		mailbox->free_parcel->prev_parcel = parcel;

	}
}


struct parcel_obj * internal_allocate_parcel(struct ipc_mailbox_object * mailbox){ api_system_gateway();

	struct parcel_obj * parcel;



	parcel = mailbox->free_parcel;

	if( mailbox->nr_free == 1){
		mailbox->nr_free = 0;           // Unmark Priority Map
	}
	else
	{
		mailbox->nr_free--;

		mailbox->free_parcel = parcel->next_parcel;

		parcel->prev_parcel->next_parcel = parcel->next_parcel;
		parcel->next_parcel->prev_parcel = parcel->prev_parcel;
	}
	return(parcel);
}

