#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\priority_services.h"


#include <stddef.h>

struct ipc_semaphore_object {						// Resource Ctrl is used by, Semaphores
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;						// Semaphore Counter
	unsigned int semaphore_apache;
};

/*
 *	Insert Task unto the Semaphores waiting list
 */
unsigned char internal_semaphore_insert_task(struct ipc_semaphore_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

/*
 *	Remove Task from the Semaphores waiting List
 */
unsigned char internal_semaphore_remove_task(struct ipc_semaphore_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

/*
 *	Schedule Highest and FIFO Task on the Semaphores witing List
 */
struct task_ctrl_obj * internal_semaphore_scheduler(struct ipc_semaphore_object *);				// Return TCB to highest task on resource


struct ipc_semaphore_object * api_create_semaphore(unsigned int, unsigned int);			// Create Semaphore
unsigned char  api_delete_semaphore(struct ipc_semaphore_object *);						// Delete Semaphore
unsigned char  api_pend_semaphore(struct ipc_semaphore_object *, unsigned int);			// Pend on Semaphore, with optional delay
unsigned char  api_post_semaphore(struct ipc_semaphore_object *);						// Post on Semhpore
unsigned char  api_accept_semaphore(struct ipc_semaphore_object *);

unsigned char  api_take_semaphore(struct ipc_semaphore_object *, unsigned int);			// Pend on Semaphore, with optional delay
unsigned char  api_give_semaphore(struct ipc_semaphore_object *);						// Post on Semhpore



struct ipc_semaphore_object * api_create_semaphore(unsigned int counter, unsigned int appache){

	api_system_gateway();
	struct ipc_semaphore_object * semaphore;

	semaphore = malloc(sizeof(struct ipc_semaphore_object));	// allocate storage for Semaphore
	if(semaphore == NULL){
		//print_dbg("Error Allocating Memory for a Semaphore\n\r");
		return(NULL);
	}

	semaphore->ipc_resource		= counter;		// Initalize the Semaphore counter
	semaphore->semaphore_apache = appache;

	for(unsigned char i = 0;i < 9; i++){
			semaphore->priority_map[i]	= EMPTY; }


	return(semaphore);	// return handle to semaphore
}

/*
 *	Delete Semaphore, return memory to the Heap
 */
unsigned char api_delete_semaphore(struct ipc_semaphore_object * semaphore){

	api_system_gateway();

	struct task_ctrl_obj * tcb;

	while(semaphore->priority_map[_group] != EMPTY){		// if deleting resource a tasks pending on
		tcb = internal_semaphore_scheduler(semaphore);			// resource then ready tasks
		if(tcb->delay_counter != Zero)					// if tasks also delayed then remove from
			internal_remove_delay(tcb);							// the delay queue
		internal_semaphore_remove_task(semaphore, tcb);			// remove from the resource
		tcb->internal_ctrl = EXCEPTION;					// set task status to EXCEPTION
		internal_kernel_insert_task(tcb);						// Insert task unto Kernel Scheduler
		}
	free(semaphore);									// free Semaphore Memory

	return(SUCCESSFUL);									// and return SUCCCESSFUL
}

/* Pend on Semaphore if it is not available with an optional timeout
   value passed in the delay field */
unsigned char api_pend_semaphore(struct ipc_semaphore_object * semaphore, unsigned int delay){

	api_system_gateway();
	struct task_ctrl_obj * tcb;

	if(semaphore->ipc_resource > Zero){		// If Semaphore count not equal zero then it is
		semaphore->ipc_resource--;			// available and return and return Semaphore ACK
		return(SEM_ACK);
	}
	else{
															// Else delay task unto Semphore prority queue
		tcb = (struct task_ctrl_obj *)core_executing_task;

		internal_kernel_remove_task(tcb);							// remove task from kernel scheduler
		internal_semaphore_insert_task(semaphore, tcb);				// insert task unto Semaphore priority queue

		if(delay != 0){										// if optional delay timeout specified then
			api_delay_task(tcb, delay);							// delay task
		}

		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		asm volatile ( "" ::: "memory");
	}

	tcb = (struct task_ctrl_obj *)core_executing_task;

	// If Task Delayed then remove from the Delay List
	if(tcb->delay_counter != 0){
		internal_remove_delay(tcb);
	}


	if(tcb->internal_ctrl == TIMEOUT){
		tcb->internal_ctrl = acknowledge;
		return(TIMEOUT);
	}
	else{
		return(SEM_ACK);				// HOOK, return status after pend completes
	}
}

/*
 *	Preform a Post Operation on the Semaphore
 */
unsigned char api_post_semaphore(struct ipc_semaphore_object * semaphore){
	api_system_gateway();


	struct task_ctrl_obj * tcb;

	// If the Semaphore has an Apache Level then ensure we have not defied the apache level
	if(semaphore->semaphore_apache != 0){
		if(semaphore->ipc_resource >= semaphore->semaphore_apache){
			return(OVERFLOW_SEM);// Return Overflow
		}
	}
	else{
		// Else increment the Semaphore Count
		semaphore->ipc_resource++;
	}

	if(semaphore->priority_map[_group] != EMPTY){	// if task waiting on Semaphore then Ready the
		tcb = internal_semaphore_scheduler(semaphore);		// the highest to run task

		semaphore->ipc_resource--;

		if(tcb->delay_counter != Zero){				// if task has a timeout specified then remove
			internal_remove_delay(tcb);						// from the delay queue
		}

		internal_semaphore_remove_task(semaphore, tcb);		// remove the task from the resource
		internal_kernel_insert_task(tcb);					// insert onto the Kernel Scheduler

		tcb->internal_ctrl = SEM_ACK;				// Set HOOK status to SEM_ACK

		if(tcb->delta_priority < core_executing_task->delta_priority){	// Test if Context swicth required after readying
			internal_executive_dispatcher();

			// There is another mechanism which can be used to achieve something similar: memory barriers.
			// This is accomplished through adding a special "memory" clobber to the assembler statement,
			// and ensures that all variables are flushed from registers to memory before the statement,
			// and then re-read after the statement.
			asm volatile ("" ::: "memory");
		}
	}
	return(SUCCESSFUL);	// Return SUCCESSFUL
}

/*
 *	Parse Semaphore Calls for simplicity
 */
unsigned char api_take_semaphore(struct ipc_semaphore_object * Semaphore, unsigned int delay){
	return(api_pend_semaphore(Semaphore, delay));
}

unsigned char api_give_semaphore(struct ipc_semaphore_object * Semaphore){
	return(api_post_semaphore(Semaphore));
}

unsigned char api_accept_semaphore(struct ipc_semaphore_object * semaphore){	// Accept Semaphore if it is available

	api_system_gateway();

	if(semaphore->ipc_resource > 0){
		semaphore->ipc_resource--;
		return(SEM_ACK);
	}
	else{
		return(FAILURE);
	}

}


																// Wait List
/* Return pointer to Highest Priority Task Ctrl Block */
struct task_ctrl_obj * internal_semaphore_scheduler(struct ipc_semaphore_object * resource){

	api_system_gateway();

	 unsigned char internal_highest_priority;
	 struct queue_ctrl_object * highest_qcb_act;
	 struct task_ctrl_obj * highest_tcb_act;

	internal_highest_priority = internal_resource_retrieve_priority(&resource->priority_map[0]);

	highest_qcb_act = &resource->priority_levels[internal_highest_priority];
	highest_tcb_act = (struct task_ctrl_obj *)highest_qcb_act->tcb_next_exe;

	return((struct task_ctrl_obj *)highest_tcb_act);
}

/* Insert task Ctrl Block of Resource Priority Pending List */
unsigned char internal_semaphore_insert_task(struct ipc_semaphore_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();
	tcb->resource_waiting = (void *)resource;

	struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedSemaphores++;
	#endif

	tcb->task_status = SEMAPHORE_WAITING;

	if( Queue->nr_tcb == Zero){
		Queue->tcb_next_exe	= tcb;
		tcb->tcb_next		= tcb;
		tcb->tcb_prev		= tcb;
		Queue->nr_tcb		= 1;
		// Mark Priority Map
		internal_resource_configure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else{
		Queue->nr_tcb++;
		tcb->tcb_next = (struct task_ctrl_obj *)Queue->tcb_next_exe;
		tcb->tcb_prev = Queue->tcb_next_exe->tcb_prev;
		Queue->tcb_next_exe->tcb_prev->tcb_next = tcb;
		Queue->tcb_next_exe->tcb_prev = tcb;
	}
	return(SUCCESSFUL);
}

/* Remove Task ctrl Block from Resourse Pending List */
unsigned char internal_semaphore_remove_task(struct ipc_semaphore_object * resource, struct task_ctrl_obj * tcb){

	api_system_gateway();

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedSemaphores--;
	#endif

	if(tcb->task_status != SEMAPHORE_WAITING){ return ERROR; }

	tcb->task_status		= DORMANT;
	tcb->internal_ctrl		= DORMANT;
	tcb->resource_waiting	= NULL;

	 struct queue_ctrl_object * Queue = &resource->priority_levels[tcb->delta_priority];

	if( Queue->nr_tcb == 1){
		Queue->nr_tcb = 0;           // Unmark Priority Map
		internal_resource_unconfigure_priority(&resource->priority_map[0], tcb->delta_priority);
	}
	else
	{
		Queue->nr_tcb--;
		if(Queue->tcb_next_exe == tcb){
			Queue->tcb_next_exe = tcb->tcb_next;
		}
		tcb->tcb_prev->tcb_next = tcb->tcb_next;
		tcb->tcb_next->tcb_prev = tcb->tcb_prev;
	}
	return(SUCCESSFUL);
}
