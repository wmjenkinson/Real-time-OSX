

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_utilities.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_bytes.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_shorts.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\buffers\buffer_words.h"


#include <stddef.h>

extern unsigned char api_buffer_flush(struct ipc_buffer_object * );
extern struct ipc_buffer_object * api_create_buffer( unsigned short int buffer_size);
extern unsigned char api_delete_buffer(struct ipc_buffer_object * );


struct page_manager * api_setup_pages(unsigned short int, unsigned short int, unsigned char, unsigned char, unsigned char, char);

void api_brownout_protection(struct page_manager *, char);
void api_kill_page_setup(struct page_manager *);

void internal_combine_pages(struct page_manager *,  struct ipc_buffer_object *);
void api_return_buffer(struct page_manager *,  struct ipc_buffer_object *);
struct ipc_buffer_object * api_alloc_buffer(struct page_manager *);



struct page_manager {
	unsigned char type;
	unsigned int nr_buffers;
	char start_death_process;
	char brownout;
	unsigned char theshold;
	unsigned char granularity;
	unsigned int size;
	unsigned int avaialble_resourses;
	struct ipc_buffer_object * next_buffer;
};

struct page_manager * api_setup_pages(unsigned short int nr_pages, unsigned short int buffer_size, unsigned char type, unsigned char theshold, unsigned char granularity, char brownout){

	api_system_gateway();

	struct ipc_buffer_object * temp_ipc;
	struct page_manager * manager;

	while((manager = api_malloc(sizeof(struct page_manager))) == NULL){
		api_delay_task(api_ownID(), 4);
	}

	manager->brownout = brownout;
	manager->type = type;
	manager->theshold = theshold;
	manager->granularity = granularity;
	manager->size = buffer_size;
	manager->nr_buffers = nr_pages;
	manager->start_death_process = false;

	for(int i = 0; i != nr_pages;i++){

		if(type == BYTE){
			temp_ipc = api_create_buffer8(buffer_size);
		}
		else if(type == WORD){
			temp_ipc = api_create_buffer16(buffer_size);
		}
		else{
			temp_ipc = api_create_buffer(buffer_size);
		}
		internal_combine_pages(manager, temp_ipc);
	}
	return(manager);
}



void api_brownout_protection(struct page_manager * manager, char onoff){
	api_system_gateway();
	manager->brownout = onoff;
}


void api_kill_page_setup(struct page_manager * manager){
	api_system_gateway();

	manager->start_death_process = true;
	manager->brownout = false;

	struct ipc_buffer_object * buffer;

	while((buffer = api_alloc_buffer(manager)) != NULL){
		manager->nr_buffers--;
		if(manager->type == BYTE){
			api_delete_buffer8(buffer);
		}
		if(manager->type == WORD){
			api_delete_buffer16(buffer);
		}
		else{
			api_delete_buffer(buffer);
		}
	}

	if(manager->nr_buffers == 0){
		api_free(manager);
	}
}


void internal_combine_pages(struct page_manager * manager,  struct ipc_buffer_object * current_buffer){

	api_system_gateway();

	if( manager->avaialble_resourses == 0){
		manager->next_buffer		 = current_buffer;
		current_buffer->next		 = current_buffer;
		current_buffer->prev		 = current_buffer;
		manager->avaialble_resourses = 1;
	}
	else{
		manager->avaialble_resourses++;
		current_buffer->next = manager->next_buffer;
		current_buffer->prev = manager->next_buffer->prev;
		manager->next_buffer->prev->next = current_buffer;
		manager->next_buffer->prev = current_buffer;
	}
}


void api_return_buffer(struct page_manager * manager, struct ipc_buffer_object * buffer){
	api_system_gateway();

	if(manager->type == BYTE){
		api_buffer_flush8(buffer);
	}
	else if(manager->type == WORD){
		api_buffer_flush16(buffer);
	}
	else{
		api_buffer_flush(buffer);
	}
	if(manager->start_death_process == true){
		manager->nr_buffers--;
		if(manager->type == BYTE){
			api_delete_buffer8(buffer);
		}
		if(manager->type == WORD){
			api_delete_buffer16(buffer);
		}
		else{
			api_delete_buffer(buffer);
		}

		if(manager->nr_buffers == 0){ api_free(manager); }
	}
	else{
		internal_combine_pages(manager, buffer);
	}
}



struct ipc_buffer_object * api_alloc_buffer(struct page_manager * manager){

	struct ipc_buffer_object * assigned_buffer;

	if(manager->avaialble_resourses < manager->theshold){

		manager->avaialble_resourses--;
		assigned_buffer = (struct ipc_buffer_object *)manager->next_buffer;
		manager->next_buffer = (struct ipc_buffer_object *)assigned_buffer->next;

		assigned_buffer->prev->next = assigned_buffer->next;
		assigned_buffer->next->prev = assigned_buffer->prev;

		if(manager->brownout == true){

			struct ipc_buffer_object * temp_ipc;

			for(unsigned char i = 0; i != manager->granularity; i++){

				manager->nr_buffers++;

				if(manager->type == BYTE){
					temp_ipc = api_create_buffer8(manager->size);
				}
				else if(manager->type == WORD){
					temp_ipc = api_create_buffer16(manager->size);
				}
				else{
					temp_ipc = api_create_buffer(manager->size);
				}
				internal_combine_pages(manager, temp_ipc);
			}
		}
	}
	else{
		manager->avaialble_resourses--;
		assigned_buffer = (struct ipc_buffer_object *)manager->next_buffer;
		manager->next_buffer = (struct ipc_buffer_object *)assigned_buffer->next;

		assigned_buffer->prev->next = assigned_buffer->next;
		assigned_buffer->next->prev = assigned_buffer->prev;
	}
	return(assigned_buffer);
}

