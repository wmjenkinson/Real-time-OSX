/*
 * futex.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_FUTEX_H_
#define DARKNESS_DX_DARKNESS_API_FUTEX_H_


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

struct ipc_futex_object {							// Resource Ctrl is used by, Futex's
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;						// Semaphore Counter
	unsigned int futex_recursion;

	struct task_ctrl_obj * holder;					// Points To Resource Holder
};

/* A futex (short for "fast userspace mutex") is a Linux construct that can be used
   to implement basic locking, or as a building block for higher-level locking
   abstractions such as semaphores.  A properly api_programmed futex-based lock will
   not use system calls except when the lock is contended; since most operations
   do not require arbitration between processes, this will not happen in most cases */
extern unsigned char internal_futex_insert_task(struct ipc_futex_object *, struct task_ctrl_obj *);		// Insert Task from Resource wait list

extern unsigned char internal_futex_remove_task(struct ipc_futex_object *, struct task_ctrl_obj *);		// Remove Task from Resource wait list

extern struct task_ctrl_obj * internal_futex_scheduler(struct ipc_futex_object *);				// Return TCB to highest task on resource

extern struct ipc_futex_object * api_create_futex(void);					// Creat Futex

extern unsigned char api_delete_futex(struct ipc_futex_object *);					// Delete Futex

extern unsigned char api_pend_futex(struct ipc_futex_object *, unsigned short int);			// Pend On Futex

extern unsigned char api_post_futex(struct ipc_futex_object *);					// Post On Futex

extern unsigned char api_accept_futex(struct ipc_futex_object *);			// Accept Futex



#endif /* DARKNESS_DX_DARKNESS_API_FUTEX_H_ */
