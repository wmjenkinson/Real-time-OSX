/*
 * rw_semaphore.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_RW_SEMAPHORE_H_
#define DARKNESS_DX_DARKNESS_API_RW_SEMAPHORE_H_


#include <stdbool.h>

struct ipc_semaphore_object_rw {
	struct queue_ctrl_object rw_queue;
	int readers;
	int writers;
	bool writing;
};

/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 *
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * semaphore_library.c
 *
 * Created: 17/09/2015 20:44:32
 *  Author: wmjen
 */
extern struct ipc_semaphore_object_rw * api_create_rw_semaphore(unsigned int, unsigned int);			// Create Semaphore
extern unsigned char  api_delete_rw_semaphore(struct ipc_semaphore_object_rw *);						// Delete Semaphore

extern unsigned char api_read_semaphore(struct ipc_semaphore_object_rw * rw_semaphore, unsigned int delay);
extern unsigned char api_write_semaphore(struct ipc_semaphore_object_rw * rw_semaphore, unsigned int delay);

extern unsigned char api_post_rd_semaphore(struct ipc_semaphore_object_rw * rw_semaphore);
extern unsigned char api_post_wr_semaphore(struct ipc_semaphore_object_rw * rw_semaphore);

extern unsigned char api_read_semaphore_preference(struct ipc_semaphore_object_rw *, unsigned int);





#endif /* DARKNESS_DX_DARKNESS_API_RW_SEMAPHORE_H_ */
