/*
 * application_mode_routine.h
 *
 * Created: 16/06/2014 13:24:19
 *  Author: William
 */
/*
 * Copyright (c) 2012 Queens University Belfast.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 *
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * event_library.c
 *
 * Created: 16/02/2017 23:05:45
 *  Author: wmjen
 */
#include <stddef.h>
#include <stdbool.h>

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\api_gateway.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\delay_core.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\micro_kernel_core.h"

#define WAIT_SET_ALL	1
#define WAIT_SET_ANY	2
#define WAIT_CLR_ALL	3
#define WAIT_CLR_ANY	4
#define CONSUME			4

#define CLR_FLAGS		5
#define SET_FLAGS		6

struct event_node {
	system_events flags;
	unsigned char opt;
	struct event_node * next_node;
	struct event_node * prev_node;
	struct task_ctrl_obj * task;
};

struct ipc_event_object {							// Resource Ctrl is used by, Events
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;
	system_events ipc_flags;						// Current status of the Event Flags

	struct event_node * free_node;
	unsigned int nr_free;

	struct event_node * node_object_ptr;			// Queue Ctrl Block Structures that Manage the Priority Queues
};

struct ipc_event_object * api_create_event_grp(system_events);										// Create Event Group
system_events api_pend_on_event(struct ipc_event_object * , system_events , unsigned char, unsigned int, unsigned char *);	// Pend on Event
system_events api_accept_event(struct ipc_event_object * , system_events , unsigned char, unsigned char *);			// Pend on Event
system_events api_signal_event(struct ipc_event_object *, system_events, unsigned char);						// Signal Event

void internal_block_on_event(struct ipc_event_object *, system_events, unsigned char, unsigned int);				// Enternal function to block calling process

void internal_crt_add_node(struct ipc_event_object *, unsigned char, system_events, unsigned char);					// Create Event Node that acts has a data structure to store enternal
unsigned char internal_remove_node(struct ipc_event_object *, struct event_node *);						// task status when waiting on a event

unsigned char internal_configure_event_controller(struct ipc_event_object * event, int nr_system_packets);
void internal_return_event_packet(struct ipc_event_object * event, struct event_node * packet);
struct event_node * internal_allocate_event_packet(struct ipc_event_object * event);


struct ipc_event_object * api_create_event_grp(system_events flags){

	api_system_gateway();
	struct ipc_event_object * event;

	event = malloc(sizeof(struct ipc_event_object));									// allocate memory for inter process ctrl
	if(event == NULL){
		//print_dbg("Error Allocating memory for event \n\r");
		return(NULL);
	}
	event->ipc_flags = flags;													// initalise flags
	event->ipc_resource = 0;

	internal_configure_event_controller(event, 500);

	return(event);
}


system_events api_pend_on_event(struct ipc_event_object * event, system_events flags, unsigned char wait_type, unsigned int delay, unsigned char * error){

	api_system_gateway();
	system_events process_flags;

	struct task_ctrl_obj * tcb;

	bool consume;

	if(wait_type & CONSUME){		// begine processing, deduce if the calling function consumes the
		wait_type  &= ~CONSUME;		// flags
		consume = true;
	}
	else{
		consume = false;
	}

	switch(wait_type) {
		case WAIT_SET_ALL:

	//		if(kernel_core.interrupt_service_routine != 0){
	//			return(ACCESS_DENIED);
	//		}

			process_flags = event->ipc_flags & flags;			// preform char AND
			if(process_flags == flags){							// if all flags match request then proceed

				if(consume){									// if calling process consumes the flags then
					event->ipc_flags &= ~process_flags;			// consume the flags
				}
				*error = SUCCESSFUL;
				return(event->ipc_flags);						// and return the current status of the flags on the
			}												// event inter process ctrl
			else{
				internal_block_on_event(event, flags, wait_type, delay);	// else char operation failed so block calling process
			}
		break;

		case WAIT_SET_ANY:

	//		if(kernel_core.interrupt_service_routine != 0){
	//			return(ACCESS_DENIED);
	//		}

			process_flags = event->ipc_flags & flags;			// test if any of the flags have been set after preforming
			if(process_flags != clear){							// a char AND operation, if so then proceed

				if(consume){										// if required, consume bits that have been set
					event->ipc_flags &= ~process_flags;
				}

				*error = SUCCESSFUL;
				return(event->ipc_flags);						// return current event bits
			}
			else{
				internal_block_on_event(event, flags, wait_type, delay);	// else block calling process
			}
		break;

		case WAIT_CLR_ALL:

	//		if(kernel_core.interrupt_service_routine != 0){
	//			return(ACCESS_DENIED);
	//		}

			process_flags = ~event->ipc_flags & flags;			// preform char operation testing if all the bits
			if(process_flags == flags){							// specified are zero

				if(consume){
					event->ipc_flags |= process_flags;			// consume flags
				}

				*error = SUCCESSFUL;
				return(event->ipc_flags);
			}
			else{
				internal_block_on_event(event, flags, wait_type, delay);	// else block calling process if the char operation failed
			}
		break;

		case WAIT_CLR_ANY:

	//		if(kernel_core.interrupt_service_routine != 0){
	//			return(ACCESS_DENIED);
	//		}

			process_flags = ~event->ipc_flags & flags;			// preform char operation to test if any bits specified
			if(process_flags != 0){								// are clear, if so the proceed

				if(consume){
					event->ipc_flags |= process_flags;			// consume flags by setting the specified bits
				}

				*error = SUCCESSFUL;
				return(event->ipc_flags);
			}
			else{
				internal_block_on_event(event, flags, wait_type, delay);	// else block calling process if char operation failed
			}
		break;

		default:
			*error = ERROR;
			return(event->ipc_flags);
		break;
	}



	tcb = (struct task_ctrl_obj *)core_executing_task;			// Catch task timeout
	if(tcb->internal_ctrl == TIMEOUT){
		tcb->internal_ctrl = acknowledge;
		*error = TIMEOUT;
		return(event->ipc_flags);
	}

	else if(consume){
		switch(wait_type){
			case WAIT_SET_ALL:
			case WAIT_SET_ANY:

			event->ipc_flags &= ~core_executing_task->tcb_flags;
			break;

			case WAIT_CLR_ALL:
			case WAIT_CLR_ANY:

			event->ipc_flags |= core_executing_task->tcb_flags;
		}
		*error = SUCCESSFUL;
	}
	return(event->ipc_flags);
}



system_events api_accept_event(struct ipc_event_object * event, system_events flags, unsigned char wait_type, unsigned char * error){

	api_system_gateway();
	system_events process_flags;

	bool consume;

	if(wait_type & CONSUME){		// begine processing, deduce if the calling function consumes the
		wait_type  &= ~CONSUME;		// flags
		consume = true;
	}
	else{
		consume = false;
	}

switch(wait_type) {
	case WAIT_SET_ALL:
		process_flags = event->ipc_flags & flags;			// preform char AND
		if(process_flags == flags){							// if all flags match request then proceed

			if(consume){										// if calling process consumes the flags then
				event->ipc_flags &= ~process_flags;			// consume the flags
			}

			*error = SUCCESSFUL;
		}													// event inter process ctrl
		else{
			*error = UNSUCCESSFUL;
		}
	return(event->ipc_flags);						// and return the current status of the flags on the
	break;

	case WAIT_SET_ANY:
	process_flags = event->ipc_flags & flags;			// test if any of the flags have been set after preforming
	if(process_flags != clear){							// a char AND operation, if so then proceed

		if(consume){									// if required, consume bits that have been set
			event->ipc_flags &= ~process_flags;
		}
		*error = SUCCESSFUL;
	}
	else{
		*error = UNSUCCESSFUL;
	}
	return(event->ipc_flags);						// return current event bits
	break;

	case WAIT_CLR_ALL:
	process_flags = ~event->ipc_flags & flags;			// preform char operation testing if all the bits
	if(process_flags == flags){							// specified are zero

		if(consume){
			event->ipc_flags |= process_flags;			// consume flags
		}
		*error = SUCCESSFUL;
	}
	else{
		*error = UNSUCCESSFUL;
	}
	return(event->ipc_flags);
	break;

case WAIT_CLR_ANY:
	process_flags = ~event->ipc_flags & flags;			// preform char operation to test if any bits specified
	if(process_flags != 0){								// are clear, if so the proceed

		if(consume){
			event->ipc_flags |= process_flags;			// consume flags by setting the specified bits
		}
		*error = SUCCESSFUL;
	}
	else{
		*error = UNSUCCESSFUL;
	}
	return(event->ipc_flags);
	break;

	default:
		*error = ERROR;
		return(event->ipc_flags);
	break;
	}
}




system_events api_signal_event(struct ipc_event_object * Event, system_events flags, unsigned char options){

	api_system_gateway();

	struct event_node * node;
	struct task_ctrl_obj * tcb;

	unsigned char i, j;

	system_events process_flags;

	switch(options){
		case CLR_FLAGS:

			Event->ipc_flags &= ~flags;

		break;

		case SET_FLAGS:
			Event->ipc_flags |= flags;
		break;
	}

	i = 0;
	j = Event->ipc_resource;

	for(i = 0; i < j;i++){											// loop through the number of tasks waiting on the event

		node = (struct event_node *)Event->node_object_ptr;								// obtain a node
		Event->node_object_ptr = node->next_node;						// move the pointer to the next node to be processed

		tcb = (struct task_ctrl_obj *)node->task;								// get the task ctrl block packaged in the node

		switch(node->opt){
			case WAIT_SET_ALL:										// test if all the bits have been set
				process_flags = Event->ipc_flags & node->flags;		// preform a char AND operation

				if(process_flags == node->flags){					// if all the bits are set then ready task

					if(tcb->delay_counter != 0){						// if the task has also been delayed then remove from delay list
						internal_remove_delay(tcb);
					}

					tcb->tcb_flags = process_flags;					// pass flags to task ctrl block
					internal_remove_node(Event, node);						// remove the node now from the Event

					internal_kernel_insert_task(tcb);						// insert task onto Kernel
				}
			break;

			case WAIT_SET_ANY:										// test if any of the bits have been set
				process_flags = Event->ipc_flags & node->flags;

				if(process_flags != 0){								// if any bits set then ready task

					if(tcb->delay_counter != 0){						// remove fromm delay list if the task has been delayed on the event
						internal_remove_delay(tcb);
					}

					tcb->tcb_flags = process_flags;					// pass flags to the task
					internal_remove_node(Event, node);						// remove node from the Event

					internal_kernel_insert_task(tcb);						// insert task back onto Kernel
					}
			break;

			case WAIT_CLR_ALL:										// wait for all bits to be cleared
				process_flags = ~Event->ipc_flags & node->flags;	// preform char operation to test if all bits our cleared

				if(process_flags == node->flags){					// if all bits are cleared then continue

					if(tcb->delay_counter != 0){						// remove task from delay list if it delayed
						internal_remove_delay(tcb);
					}

					tcb->tcb_flags = process_flags;					// pass the flags to the task
					internal_remove_node(Event, node);						// and remove node

					internal_kernel_insert_task(tcb);						// insert delayed task back onto kernel
				}
			break;

			case WAIT_CLR_ANY:										// test if any of the flags are cleared
				process_flags = ~Event->ipc_flags & node->flags;

				if(process_flags != 0){								// if any flags are cleared then proceed

					if(tcb->delay_counter != 0){						// remove task from the delay list if it is delayed
						internal_remove_delay(tcb);
					}

					tcb->tcb_flags = process_flags;					// pass flags to task
					internal_remove_node(Event, node);						// remove node from the event

					internal_kernel_insert_task(tcb);						// insert task back onto kernel
				}
			break;
		}
	}
	if(internal_highest_priority() < core_executing_task->delta_priority){					// If Task has been made READY and is of Higher Priority then
		internal_executive_dispatcher();

		// There is another mechanism which can be used to achieve something similar: memory barriers.
		// This is accomplished through adding a special "memory" clobber to the assembler statement,
		// and ensures that all variables are flushed from registers to memory before the statement,
		// and then re-read after the statement.
		asm volatile ("" ::: "memory");
	}
	return(Event->ipc_flags);
}


/* Block on event blocks the calling proess if the required char operation failed, the blocking function will
   be wrapped in a structure called a node */
void internal_block_on_event(struct ipc_event_object * event, system_events flags, unsigned char wait_type, unsigned int delay){

	api_system_gateway();

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedEvents++;
	#endif

	struct task_ctrl_obj * tcb = (struct task_ctrl_obj *)core_executing_task;

	internal_kernel_remove_task(tcb);						// remove blocking proces from kernel
	internal_crt_add_node(event, wait_type, flags, delay);	// create a node structure, packaging the calling task into a node

	tcb->resource_waiting = (void *)event;					// specify that the process is waiting on this event

	if(delay != 0){
		api_delay_task(tcb, delay);						// if a delay is specified then also place the process on the delay queue
	}

	internal_executive_dispatcher();

	// There is another mechanism which can be used to achieve something similar: memory barriers.
	// This is accomplished through adding a special "memory" clobber to the assembler statement,
	// and ensures that all variables are flushed from registers to memory before the statement,
	// and then re-read after the statement.
	asm volatile ("" :::"memory");					// preform context switch

	#ifdef DARKNESSDEBUG
		DebugX.NrTasksDelayedEvents--;
	#endif
}

/* create a node structure to package the task ctrl block and required information for the event */
void internal_crt_add_node(struct ipc_event_object * pending_event, unsigned char wait_type, system_events flags, unsigned char delay){

	api_system_gateway();

	struct task_ctrl_obj * tcb;

	struct event_node * node;
	node = internal_allocate_event_packet(pending_event);

	tcb = (struct task_ctrl_obj *)core_executing_task;	// obtain calling task ctrl block
	tcb->node_object = node;							// complete the node by loading the required data

	node->flags		 = flags;							// onto the structure
	node->opt		 = wait_type;
	node->task       = tcb;
	tcb->task_status = WAITING_ON_EVENT;					// specify that the proess is waiting on a node

	if( pending_event->ipc_resource == 0){				// place the node onto a double link list
		pending_event->node_object_ptr	= node;
		node->next_node					= node;
		node->prev_node					= node;
		pending_event->ipc_resource		= 1;
	}
	else{
		pending_event->ipc_resource++;
		node->next_node = (struct event_node *)pending_event->node_object_ptr;
		node->prev_node = pending_event->node_object_ptr->prev_node;
		pending_event->node_object_ptr->prev_node->next_node = node;
		pending_event->node_object_ptr->prev_node = node;
	}
}



// Remove the node from the double linked list
unsigned char internal_remove_node(struct ipc_event_object * working_event, struct event_node * node){

	api_system_gateway();

	if(node->task->task_status != WAITING_ON_EVENT){ return ERROR; }

	if( working_event->ipc_resource == 1){
		working_event->ipc_resource = 0;
	}
	else
	{
		working_event->ipc_resource--;
		if(working_event->node_object_ptr == node)
			working_event->node_object_ptr = node->next_node;
		node->prev_node->next_node = node->next_node;
		node->next_node->prev_node = node->prev_node;
	}

	internal_return_event_packet(working_event, node);	// free node data structure
	return SUCCESSFUL;
}



unsigned char internal_configure_event_controller(struct ipc_event_object * event, int nr_system_packets){

	api_system_gateway();


	struct event_node * packet;

	for(int i = 0; i < nr_system_packets; i++){

		packet = malloc(sizeof(struct event_node));
		internal_return_event_packet(event, packet);
	}
	return (true);
}



void internal_return_event_packet(struct ipc_event_object * event, struct event_node * packet){ api_system_gateway();


	if( event->nr_free == 0){
		event->free_node									= packet;
		packet->next_node									= packet;
		packet->prev_node									= packet;
		event->nr_free										= 1;
	}
	else{
		event->nr_free++;
		packet->next_node = event->free_node;
		packet->prev_node = event->free_node->prev_node;
		event->free_node->prev_node->next_node = packet;
		event->free_node->prev_node = packet;

	}
}



struct event_node * internal_allocate_event_packet(struct ipc_event_object * event){

	api_system_gateway();

	struct event_node * packet;



	packet = event->free_node;

	if( event->nr_free == 1){
		event->nr_free = 0;           // Unmark Priority Map
	}
	else
	{
		event->nr_free--;

		event->free_node = packet->next_node;

		packet->prev_node->next_node = packet->next_node;
		packet->next_node->prev_node = packet->prev_node;
	}
	return(packet);
}
