/*
 * event_library.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_EVENT_LIBRARY_H_
#define DARKNESS_DX_DARKNESS_API_EVENT_LIBRARY_H_


#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

#define WAIT_SET_ALL	1
#define WAIT_SET_ANY	2
#define WAIT_CLR_ALL	3
#define WAIT_CLR_ANY	4
#define CONSUME			4

#define CLR_FLAGS		5
#define SET_FLAGS		6

struct event_node {
	system_events flags;
	unsigned char opt;
	struct event_node * next_node;
	struct event_node * prev_node;
	struct task_ctrl_obj * task;
};


struct ipc_event_object {							// Resource Ctrl is used by, Events
	struct queue_ctrl_object priority_levels[64];	// Priority Levels hold Tasks WAITING to Obtain Structure
	unsigned char priority_map[9];					// Priority Map used to Find the Highest Priority Task WAITING
	unsigned int ipc_resource;
	system_events ipc_flags;						// Current status of the Event Flags

	struct event_node * free_node;
	unsigned int nr_free;

	struct event_node * node_object_ptr;			// Queue Ctrl Block Structures that Manage the Priority Queues
};

extern struct ipc_event_object * api_create_event_grp(system_events);										// Create Event Group
extern system_events api_pend_on_event(struct ipc_event_object * , system_events , unsigned char, unsigned int, unsigned char *);	// Pend on Event
extern system_events api_accept_event(struct ipc_event_object * , system_events , unsigned char, unsigned char *);			// Pend on Event
extern system_events api_signal_event(struct ipc_event_object *, system_events, unsigned char);						// Signal Event

extern void internal_block_on_event(struct ipc_event_object *, system_events, unsigned char, unsigned int);				// Enternal function to block calling process

extern void internal_crt_add_node(struct ipc_event_object *, unsigned char, system_events, unsigned char);					// Create Event Node that acts has a data structure to store enternal
extern unsigned char internal_remove_node(struct ipc_event_object *, struct event_node *);						// task status when waiting on a event

extern unsigned char internal_configure_event_controller(struct ipc_event_object * event, int nr_system_packets);
extern void internal_return_event_packet(struct ipc_event_object * event, struct event_node * packet);
extern struct event_node * internal_allocate_event_packet(struct ipc_event_object * event);



#endif /* DARKNESS_DX_DARKNESS_API_EVENT_LIBRARY_H_ */
