/*
 * watchdog.h
 *
 *  Created on: 1 Oct 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_DARKNESS_API_WATCHDOG_H_
#define DARKNESS_DX_DARKNESS_API_WATCHDOG_H_



struct watchdog_application {
	signed long int watchdog_time;
	unsigned long int system_notice;
};


extern struct watchdog_application * api_createwatchdog(int);

extern void api_ping_watchdog(struct watchdog_application * );

extern char api_pong_watchdog(struct watchdog_application * );



#endif /* DARKNESS_DX_DARKNESS_API_WATCHDOG_H_ */
