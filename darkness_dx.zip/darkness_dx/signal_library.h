#ifndef DARKNESS_DX_SIGNAL_LIBRARY_H_
#define DARKNESS_DX_SIGNAL_LIBRARY_H_

#include "\atmel-software-package-master\examples\getting_started\darkness_dx/structs.h"

struct ipc_signal_sent {
	struct signal_pending * start;
	unsigned short int  nr_signal_received;
};

struct signal_pending {
	unsigned short int  signal_cmd;
	struct signal_pending * next_signal;
	struct signal_pending * prev_signal;
};

struct signal_memory_management {
	struct signal_pending * free_ptr;
	unsigned short int  nr_signals;
}  Darkness_Signals;

/********************************************************************************/

struct ipc_signal_obj {
	struct signal_ctrl_obj * start;
	unsigned short int  nr_signal_registered;
};

struct signal_ctrl_obj {
	void * __handler;
	unsigned short int signal_nr;
	struct signal_ctrl_obj * next;
	struct signal_ctrl_obj * prev;
};


extern void internal_signal_server(struct task_ctrl_obj * );

extern unsigned char api_register_signal(void *, unsigned char);

extern unsigned char api_unregister_signal(void *, unsigned char);

extern unsigned char api_send_signal(struct task_ctrl_obj *, unsigned char);

extern unsigned char internal_check_registery(struct task_ctrl_obj *, unsigned char);

extern void  internal_acknowledge_signals(struct task_ctrl_obj *);

extern unsigned char internal_configure_signals(int nr_system_packets);

extern struct signal_pending * internal_allocate_signal(void);

extern void internal_return_signal(struct signal_pending * signal);




#endif /* DARKNESS_DX_SIGNAL_LIBRARY_H_ */
