//#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\system_malloc.h"

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"
#include "D:\atmel-software-package-master\examples\getting_started\darkness_dx\darkness_api\semaphore_library.h"


#include "stddef.h"

/* Symbol defined by linker map */
char  end_[10000000];              /* start of free memory (as symbol) */


static void * __sbrk (int nbytes)
{
    /* The statically held previous end of the heap, with its initialization. */
    static char * heap_ptr = (void *)&end_[0];         /* Previous end */

    void * base  = heap_ptr;
    heap_ptr   += nbytes;

    return  base;
}

static inline size_t word_align(size_t size) {
    return size + ((sizeof(size_t) - 1) & ~(sizeof(size_t) - 1));
}



struct chunk {

    struct chunk  *next,
				  *prev;

    size_t        size;
    int           free;
    void          *data;
};



typedef struct chunk *Chunk;



static void *malloc_base(void) {

    static Chunk b = NULL;

    if (!b) {

        b = __sbrk(word_align(sizeof(struct chunk)));

        if (b == (void*) -1) {
            return 0;
        }
        b->next = NULL;
        b->prev = NULL;
        b->size = 0;
        b->free = 0;
        b->data = NULL;
    }
    return b;
}



static Chunk malloc_chunk_find(size_t s, Chunk *heap) {

    Chunk c = malloc_base();

    for (; c && (!c->free || c->size < s); *heap = c, c = c->next);

    return c;

}



static void malloc_merge_next(Chunk c) {

    c->size = c->size + c->next->size + sizeof(struct chunk);
    c->next = c->next->next;

    if (c->next) {
        c->next->prev = c;
    }
}



static void malloc_split_next(Chunk c, size_t size) {

    Chunk newc = (Chunk)((char*) c + size);
    newc->prev = c;
    newc->next = c->next;
    newc->size = c->size - size;
    newc->free = 1;
    newc->data = newc + 1;
    if (c->next) {
        c->next->prev = newc;
    }
    c->next = newc;
    c->size = size - sizeof(struct chunk);
}




void * malloc(size_t size);
void * malloc(size_t size) {

    if (!size) return NULL;

    if(memory_controller != NULL)
    	api_pend_semaphore(memory_controller, 0);

    size_t length = word_align(size + sizeof(struct chunk) + 4);

    Chunk prev = NULL;
    Chunk c = malloc_chunk_find(size, &prev);

    if (!c) {

        Chunk newc = __sbrk(length);

        if (newc == (void*) -1) {
            return NULL;
        }
        newc->next = NULL;
        newc->prev = prev;
        newc->size = length - sizeof(struct chunk);
        newc->data = newc + 1;
        prev->next = newc;
        c = newc;
    } else if (length + sizeof(size_t) < c->size) {
        malloc_split_next(c, length);
    }
    c->free = 0;

    if(memory_controller != NULL)
        api_post_semaphore(memory_controller);

    return c->data;
}




void free(void *ptr);
void free(void *ptr) {


	if(memory_controller != NULL)
	    api_pend_semaphore(memory_controller, 0);

    if (!ptr || ptr < malloc_base() || ptr > __sbrk(0)){

    	if(memory_controller != NULL)
    	    api_post_semaphore(memory_controller);
    	return;
    }

    Chunk c = (Chunk) ptr - 1;

    if (c->data != ptr){

    	if(memory_controller != NULL)
    	    api_post_semaphore(memory_controller);
    	return;
    }

    c->free = 1;


    if (c->next && c->next->free) {
        malloc_merge_next(c);
    }
    if (c->prev->free) {
        malloc_merge_next(c = c->prev);
    }
    if (!c->next) {
        c->prev->next = NULL;
        __sbrk(- c->size - sizeof(struct chunk));
    }

    if(memory_controller != NULL)
        api_post_semaphore(memory_controller);
}




void *calloc(size_t nmemb, size_t size);
void *calloc(size_t nmemb, size_t size) {

	if(memory_controller != NULL)
	    api_pend_semaphore(memory_controller, 0);

    size_t length = nmemb * size;

    void *ptr = malloc(length);

    if (ptr) {
        char *dst = ptr;
        for (size_t i = 0; i < length; *dst = 0, ++dst, ++i);
    }

    if(memory_controller != NULL)
        api_post_semaphore(memory_controller);

    return ptr;
}




void *realloc(void *ptr, size_t size);
void *realloc(void *ptr, size_t size) {

	if(memory_controller != NULL)
	    api_pend_semaphore(memory_controller, 0);

	void *newptr = malloc(size);

    if (newptr && ptr && ptr >= malloc_base() && ptr <= __sbrk(0)) {
        Chunk c = (Chunk) ptr - 1;
        if (c->data == ptr) {
            size_t length = c->size > size ? size : c->size;
            char *dst = newptr, *src = ptr;
            for (size_t i = 0; i < length; *dst = *src, ++src, ++dst, ++i);
            //free(ptr);
        }
    }

    if(memory_controller != NULL)
        api_post_semaphore(memory_controller);

    return newptr;
}

