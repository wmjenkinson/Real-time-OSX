/*
 * micro_kernel_core.h
 *
 *  Created on: 21 Aug 2018
 *      Author: wmjen
 */

#ifndef DARKNESS_DX_MICRO_KERNEL_CORE_H_
#define DARKNESS_DX_MICRO_KERNEL_CORE_H_

#include "\atmel-software-package-master\examples\getting_started\darkness_dx\structs.h"

/* The following Function are used to interface directly with the Kernel and also for the Kernel to Manage
   The MCU Resources. It includes some common user interfaces */
extern unsigned char internal_kernel_insert_task(struct task_ctrl_obj *);				// Inserts a Task unto the Kernel, using a double link list
extern unsigned char internal_kernel_remove_task(struct task_ctrl_obj *);				// Removes a task from the kernel using a double link list

extern struct task_ctrl_obj * api_ownID(void);
extern struct task_ctrl_obj * kernel_scheduler(void);

extern void start_kernel (void);
extern void internal_executive_dispatcher(void);

extern unsigned char internal_highest_priority(void);

extern void internal_hardware_dispatcher(void);


#endif /* DARKNESS_DX_MICRO_KERNEL_CORE_H_ */
